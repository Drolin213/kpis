public function ImportarEstudiantes(){
            if ($_SERVER['REQUEST_METHOD'] == 'POST'){      
               
    $allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
              
                if(in_array($_FILES["file"]["type"],$allowedFileType)){
                    $targetPath = '../public/documents/DOCUMENTOS_IMPORTADOS/'.$_FILES['file']['name'];
                    move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
                    $Reader = new SpreadsheetReader($targetPath);
                    $sheetCount = count($Reader->sheets());
                    $db = $this->connect();
                    for($i=0;$i<$sheetCount;$i++)
                    {
                        $Reader->ChangeSheet($i);
                        foreach ($Reader as $Row)
                        {
                            $codigo = 0;
                            if(isset($Row[0])) {
                                $codigo = mysqli_real_escape_string($db,$Row[0]);
                            }
                            
                            $nombres = "";
                            if(isset($Row[1])) {
                                $nombres = mysqli_real_escape_string($db,$Row[1]) ;
                            }
                            
                            $apellidos = "";
                            if(isset($Row[2])) {
                                $apellidos = mysqli_real_escape_string($db,$Row[2]);
                            }
                            
                            $grado = "";
                            if(isset($Row[3])) {
                                $grado = mysqli_real_escape_string($db,$Row[3]);
                            }

                            $grupo = 0;
                            if(isset($Row[4])) {
                                $grupo = mysqli_real_escape_string($db,$Row[4]);
                            }

                            $correo = "";
                            if(isset($Row[5])) {
                                $correo = mysqli_real_escape_string($db,$Row[5]);
                            }

                            $identificacion = 0;
                            if(isset($Row[6])) {
                                $identificacion = mysqli_real_escape_string($db,$Row[6]) ;
                            }

                            $estadoAcademico = "";
                            if(isset($Row[7])) {
                                $estadoAcademico = mysqli_real_escape_string($db,$Row[7]) ;
                            }

                            $cargo = "";
                            if(isset($Row[8])) {
                                $cargo = mysqli_real_escape_string($db,$Row[8]) ;
                            }
                            $datos = [
                                'codigo' => $codigo,
                                'nombres' => $nombres,
                                'apellidos' => $apellidos,
                                'grado' =>  $grado,
                                'grupo' => $grupo,
                                'correo' => $correo,
                                'identificacion' => $identificacion,
                                'estadoAcademico' => $estadoAcademico,
                                'cargo' => $cargo
                            ];
                            if (!empty($datos)) {
                                if ($this->EstudianteModel->ImportarEstudiantes($datos)){
                                    header('location:' . URL_SEE . 'Estudiante/ListarEstudiantes');
                                    $type = "success";
                                    $message = "Excel importado correctamente";
                                } else {
                                    $type = "error";
                                    $message = "Hubo un problema al importar registros";
                                }
                            }
                        }
                    }
                    
                }
            }else{ 
                $type = "error";
                $message = "El archivo enviado es invalido. Por favor vuelva a intentarlo";
            }
        }