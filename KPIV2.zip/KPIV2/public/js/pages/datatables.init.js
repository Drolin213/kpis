
$(document).ready(function() {
    $('#datatable').DataTable();

    //Buttons examples
    var table = $('#datatable-buttons').DataTable({
        lengthChange: false,
        buttons: ['colvis','copy', 'excel',{
            extend: 'pdf', // Botón de exportación a PDF
            text: 'PDF',
            title: 'Usuarios creados en KPI', // Cambia el título del PDF
        },]
    });

    table.buttons().container()
        .appendTo('#datatable-buttons_wrapper .col-md-6:eq(0)');

    $(".dataTables_length select").addClass('form-select form-select-sm');


} );