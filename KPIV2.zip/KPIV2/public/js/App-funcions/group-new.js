
const alertNewGroup = document.getElementById("alertNewGroup");
const contTextAlertNotification = document.getElementById("textAlertNotification");
let textAlertNotification = "";
loadListGroups();

function validateFormNewGroup() {
    let area = document.querySelector('select[name="area"]').value;
    let name = document.querySelector('input[name="name"]').value;
    let manager = document.querySelector('input[name="manager"]').value;
    let description = document.querySelector('textarea[name="description"]').value;
    
    if (area !== "" && name !== "" && manager !== "" && description !== "") {
        const group = {
            area: area,
            name: name, 
            description: description, 
            manager : manager
        };

        funcionExample(group);
    } else {
        textAlertNotification += "- Llene todos los campos del formulario <br>";
        contTextAlertNotification.innerHTML = textAlertNotification;
        alertNewGroup.style.display = "block";
    }
    
}

function funcionExample(group) {
    console.log(group);
}

function loadListGroups() {
    const listGroups = {
        area: "area",
        name: "name", 
        manager : "manager",
        dataCreate : "dataCreate",
        description : "description",
        idGroup : "1"
    };
    document.getElementById("titleGroup").textContent = listGroups.area;
    document.getElementById("titleGroup").textContent = listGroups.name;
    document.getElementById("manager").textContent = listGroups.manager;
    document.getElementById("dateCreate").textContent = listGroups.dataCreate;
    document.getElementById("descriptionGroup").textContent = listGroups.description;
    var img1 = document.getElementById("groups1");
    img1.src = "assets/images/groups/groups 1.png";
    console.log(listGroups);
    
}