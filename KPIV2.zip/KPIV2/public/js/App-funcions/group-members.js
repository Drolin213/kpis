
$(document).ready(function() {
    resultListGroups = $('#resultListGroups').DataTable({
        columns: [
            { data: 'Usuario' },
            { data: 'Nombres' },
            { data: 'Apellidos' },
            { data: 'Correo' }
        ]
    });
});

let contTextAlertModalNewMember = document.getElementById('textAlertModalNewMember');
let conttextAlertModalNewKpi = document.getElementById('textAlertModalNewKpi');
let alertModalNewMember = document.getElementById('alertModalNewMember');
let alertModalNewKpi = document.getElementById('alertModalNewKpi');
let sessionListgroups = document.getElementById("listgroups");
let sessionOpcionGroups = document.getElementById("opcionGroups");
let groupModalNewMember = document.getElementById("groupModalNewMember");
let idGroup;

function loadDataGroup(id) {
    idGroup = id;
    groupModalNewMember.innerHTML = "Nuevo integrante - Grupo:" +idGroup;
    loadGroup(id);
    loadKpis(id);
    
}


function loadGroup(idGroup) {

    let num = 100;

    resultListGroups.clear().draw();
    for (let index = 0; index < num; index++) {
        resultListGroups.row.add({
            "Usuario":      `Usuario`,
            "Nombres":      `Nombres`,
            "Apellidos":    `Apellidos`,
            "Correo":       `Correo`,
        }).draw();
        
    }


    sessionListgroups.style.display = 'none';
    sessionOpcionGroups.style.display = 'block';
    
}

function loadKpis(idGroup) {
    var listaKpis = document.getElementById('loadListKpis');

// Llena la lista con 100 elementos <li>
    for (var i = 0; i < 100; i++) {
        var li = document.createElement('li');
        li.className = 'feed-item';

        var div = document.createElement('div');
        div.className = 'feed-item-list';

        // Crea el enlace <a> para el nombre
        var a = document.createElement('a');
        a.id = 'nombreKpi';
        a.textContent = 'Nombre';
        a.setAttribute('onclick', 'openModalEditKpi(' + (i + 1) + ')'); // Se asigna un ID único a cada elemento

        // Agrega el enlace al div
        div.appendChild(a);

        var spansText = [
            '-Objetivo: Lorem ipsum dolor sit, amet consectetur adipisicing elit...',
            '-Metrica: Lorem ipsum dolor sit, amet consectetur adipisicing elit...',
            '-Target: Lorem ipsum dolor sit, amet consectetur adipisicing elit...',
            '-Cumplimiento Qn: Lorem ipsum dolor sit, amet consectetur adipisicing elit...'
        ];

        for (var j = 0; j < spansText.length; j++) {
            var spanText = document.createElement('span');
            spanText.className = 'activity-text';
            spanText.textContent = spansText[j];
            div.appendChild(spanText);
        }

        li.appendChild(div);

        listaKpis.appendChild(li);
    }
    
}

function loadListGroup() {
    sessionListgroups.style.display = 'block';
    sessionOpcionGroups.style.display = 'none';
}

function openModalEditKpi(idKpi) {
    alert(idKpi);
}


function loadDataFormNewMember() {
    let textAlertModalNewMember = "";

    let idUser = document.querySelector('input[name="userId"]').value;

    if (idUser !== "") {
        const userDataNewMember = {
            idUser: idUser,
            idGroup: idGroup
        };
        console.log(userDataNewMember);

        //serviseUserLogin(userLogin);
        return false;
    } else {
        textAlertModalNewMember += "- Ingrese todos los datos solicitados <br>";
        contTextAlertModalNewMember.innerHTML = textAlertModalNewMember;
        alertModalNewMember.style.display = "block";
        return false;
    }
}

function loadDataFormNewKpi() {
    let textAlertModalNewKpi = "";

    let targetQ = document.querySelector('input[name="targetQ"]').value;
    let targetMoth = document.querySelector('input[name="targetMoth"]').value;
    let targetWeek = document.querySelector('input[name="targetWeek"]').value;
    let kpiParameter = document.querySelector('select[name="kpiParameter"]').value;
    let nameMetrics = document.querySelector('input[name="nameMetrics"]').value;
    let kpiObjetive = document.querySelector('input[name="kpiObjetive"]').value;
    let kpiName = document.querySelector('input[name="kpiName"]').value;

    if (targetQ !== "" && targetMoth !== "" && targetWeek !== "" && kpiParameter !== "" && nameMetrics !== "" && kpiObjetive !== "" && kpiName !== "") {
        const userDataNewKpi = {
            targetQ: targetQ,
            targetMoth: targetMoth,
            targetWeek: targetWeek,
            kpiParameter: kpiParameter,
            nameMetrics: nameMetrics,
            kpiObjetive: kpiObjetive,
            kpiName: kpiName,
        };
        console.log(userDataNewKpi);

        //serviseUserLogin(userLogin);
        return false;
    } else {
        textAlertModalNewKpi += "- Ingrese todos los datos solicitados <br>";
        conttextAlertModalNewKpi.innerHTML = textAlertModalNewKpi;
        alertModalNewKpi.style.display = "block";
        return false;
    }
}