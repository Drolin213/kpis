const alertLogin = document.getElementById("alertLogin");
const contTextAlertNotification = document.getElementById("textAlertNotification");

function loadDataUserLogin() {
    let textAlertNotification = "";
    let idUser = document.querySelector('input[name="idUser"]').value;
    let userPassword = document.querySelector('input[name="userPassword"]').value;

    if (idUser !== "" || userPassword !== "") {
        const userLogin = {
            idUser: idUser,
            userPassword: userPassword
        };

        serviseUserLogin(userLogin);
    } else {
        textAlertNotification += "- Usuario y/o contraseña inválidos <br>";
        contTextAlertNotification.innerHTML = textAlertNotification;
        alertLogin.style.display = "block";
    }
}

function serviseUserLogin(userLogin) {
    
    var url = "validateUser/Account";
    var data =
    {
        user: document.getElementById("jsUser").value,
        password: document.getElementById("jsPassword").value
    };
    $.ajax({
        url: url,
        type: 'POST',
        data: data,
        success: function (data) {
            if (data == 1) {
                window.location.href = "../App/Index";
            }
            else {
                mensaje_1("Credenciales incorrectas");
            }
        },
        error: function (request, status, error) {
            alert(request.responseText);
        }
    });
    console.log(userLogin);
}
