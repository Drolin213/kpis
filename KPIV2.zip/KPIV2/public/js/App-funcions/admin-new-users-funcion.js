// Declarar las variables en un ámbito global
let datatable;
let resultuserDataCreate;

$(document).ready(function() {
    datatable = $('#datatable').DataTable({
        columns: [
            { data: 'Usuario' },
            { data: 'Nombres' },
            { data: 'Apellidos' },
            { data: 'Correo' },
            { data: 'Identificación' }
        ]
    });

    resultuserDataCreate = $('#resultuserDataCreate').DataTable({
        columns: [
            { data: 'Usuario' },
            { data: 'Nombres' },
            { data: 'Apellidos' },
            { data: 'Correo' },
            { data: 'Identificación' }
        ]
    });

    // Puedes realizar otras acciones dentro de $(document).ready() si es necesario
});

function displayUserData(jsonData) {
    let userData = JSON.parse(jsonData);
    let viewUserData = document.querySelector('#ViewUserData');
    datatable.clear().draw();
    resultuserDataCreate.clear().draw();
    viewUserData.innerHTML = "";

    // Verificar si userData es una matriz
    if (Array.isArray(userData)) {
        userData.forEach(item => {
            // Escapar los valores de los objetos JSON
            let idUser = encodeURIComponent(item.IdUser);
            let name = encodeURIComponent(item.Name);
            let lastName = encodeURIComponent(item.LastName);
            let email = item.Email;
            let idFiscal = encodeURIComponent(item.IdFiscal);
            if (idFiscal != "") {
                datatable.row.add({
                    "Usuario":      `${idUser}`,
                    "Nombres":      `${name}`,
                    "Apellidos":    `${lastName}`,
                    "Correo":       `${email}`,
                    "Identificación": `${idFiscal}`,
                }).draw();
            }
        });
    } else {
        console.error('userData no es una matriz.');
    }
}

function serviceCreateUsers(jsonData) {
    alert("Creando usuarios")
    let jsonUserData = JSON.parse(jsonData);

    $.ajax({
        type: 'POST',  // Método HTTP (puede ser POST o GET, dependiendo de tus necesidades)
        url: 'URL_DEL_SERVICIO',  // URL del servicio web
        data: jsonUserData,  // Convierte el objeto en una cadena JSON
        contentType: 'application/json',  // Tipo de contenido de la solicitud
        dataType: 'json',  // Tipo de contenido esperado en la respuesta
        success: function(response) {
            // Maneja la respuesta JSON aquí
            console.log(response);
        },
        error: function(xhr, status, error) {
            // Maneja los errores aquí
            console.error('Error en la solicitud:', error);
        }
    });
}

function validateUsersCreate(){
    
}

function openLinkInNewWindow(url) {
    // Abre el enlace en una nueva ventana del navegador
    window.open(url);
}

