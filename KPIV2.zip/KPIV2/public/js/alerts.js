
    
    function success() {
        Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Guardado exitosamente',
            showConfirmButton: false,
            timer: 3000
          })
    }
    function succes() {
        Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Actualizado exitosamente',
            showConfirmButton: false,
            timer: 3000
          })
    }
    

    function error(){
        Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'No se pudo guardar',
            showConfirmButton: false,
            timer: 3000
          })
    }
    
    function NoCumple(){
        Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'Fecha Inicial debe ser menor que la Fecha Final',
            showConfirmButton: false,
            timer: 4000
          })
    }

    function fillData() {
        Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'Por favor llene los campos',
            showConfirmButton: false,
            timer: 3000
        })
    }
    function SelecioneFeha() {
        Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'Por favor seleccione una fecha',
            showConfirmButton: false,
            timer: 3000
        })
    }
    function IngresarTipoVacuna() {
        Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'Por favor ingrese el Tipo de Vacuna',
            showConfirmButton: false,
            timer: 3000
        })
    }

    function IngresarPrimeraFecha() {
        Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'Por favor ingrese la Fecha de la Primera vacuna',
            showConfirmButton: false,
            timer: 4000
        })
    }

    function error2(){
        Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'No se pudo actualizar la regional',
            showConfirmButton: false,
            timer: 3000
          })
    }

    function edit() {
        Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'Regional actualizada exitosamente',
            showConfirmButton: false,
            timer: 3000
        })

    }

    function Delete(){
        Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'eliminado exitosamente',
            showConfirmButton: false,
            timer: 3000
        })
    }
    function errorDelete(){
        Swal.fire({
            position: 'center',
            icon: 'error',
            title: 'No se pudo borrar la regional',
            showConfirmButton: false,
            timer: 3000
          })
    }

    function existe(){
        Swal.fire({
            position: 'center',
            icon: 'warning',
            title: 'La regional ya existe ',
            showConfirmButton: false,
            timer: 3000
        })
    }

   


    