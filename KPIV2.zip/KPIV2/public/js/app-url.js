if (window.location.pathname.endsWith('.html')) {
    var newUrl = window.location.pathname.replace('.html', '');
}