<?php
    class Home extends Controlador{
        
        public function __construct(){
            $this->HomeModel = $this->modelo('HomeModel');
        }

        public function Index(){
            if($_SESSION['sesion_active']['tipo_usuario'] == 'T'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
           
            if (!isset($_SESSION['sesion_active'])){
                header('location:' . URL_SEE . 'Login/Logout');
            }else{
                
                $this->vista('home/index',);
            }
        }

        public function dashboardAprendiz(){
            if($_SESSION['sesion_active']['tipo_usuario'] == 'I'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
            if (!isset($_SESSION['sesion_active'])){
               header('location:' . URL_SEE . 'Login/Logout');
            }else{
                
                $this->vista('home/dashboardAprendiz');
            }
           
        }

        public function ToltalGrupo(){
            $Listar = $this->HomeModel->TotalGrupo();
            
            echo json_encode($Listar->TOTAL); // Devuelve solo el valor 'TOTAL'
        }
        public function Toltalusuario(){
            $Listar = $this->HomeModel->TotalUsuario();
            
            echo json_encode($Listar->TOTAL); // Devuelve solo el valor 'TOTAL'
        }
        public function ToltalKpis(){
            $Listar = $this->HomeModel->ToltalKpis();
            
            echo json_encode($Listar->TOTAL); // Devuelve solo el valor 'TOTAL'
        }



        public function ReporteDia(){
            $Listar = $this->HomeModel->ToltalDia();
            
            echo json_encode($Listar); // Devuelve solo el valor 'TOTAL'
        }



       
    }
?>