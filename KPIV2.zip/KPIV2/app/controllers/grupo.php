<?php
    class grupo extends Controlador{

        public function __Construct(){
            $this->GruposModel = $this->modelo('GruposModel');
            if(!isset($_SESSION['sesion_active'])):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'APRENDIZ'):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'INSTRUCTOR'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
        }
        public function ListarGrupo(){
            $ListarGrupo = $this->GruposModel->ListarGrupo();
            $datos = ['ListarGrupo' => $ListarGrupo];
            $this->vista('configuracion/grupo/ListarGrupo', $datos);
        }
       
        public function CrearGrupo(){
            $ListarGrupo = $this->GruposModel->ListarGrupo();
            $datos = ['ListarGrupo' => $ListarGrupo];
            $this->vista('configuracion/grupo/CrearGrupo', $datos);
        }

        public function ToltalGrupo(){
            $Listar = $this->GruposModel->TotalGrupo();
            
            echo json_encode($Listar->TOTAL); // Devuelve solo el valor 'TOTAL'
        }
        public function Toltalusuario(){
            $Listar = $this->GruposModel->TotalUsuario();
            
            echo json_encode($Listar->TOTAL); // Devuelve solo el valor 'TOTAL'
        }

        public function ObtenerAprendiz($IdGrupo){
        
            $result = $this->GruposModel->ObtenerIdGrupo($IdGrupo);
            $datos = [
                'IdGrupo' => $IdGrupo
                
            ];

            $this->vista('configuracion/grupo/ListarGrupo', $datos);
        }

        public function ValidaExistencia(){
            $numID = trim($_POST['numID']);
            $resulset = $this->GruposModel->ValidaExistencia($numID);
            echo json_encode($resulset);
        }
    
        public function InsertarGrupo(){
            $create_fecha = date('Y-m-d H:i:s');
            $estado = 1;
        
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $datos = [
                    'area' => trim($_POST['area']),
                    'nombres' => trim($_POST['nombres']),
                    'manager' => trim($_POST['manager']),
                    'description' => trim($_POST['description']),
                    'create_fecha' => $create_fecha,
                    'estado' => $estado
                ];
                
                
            }
            $this->GruposModel->Insertar($datos);
        }

    }
?>