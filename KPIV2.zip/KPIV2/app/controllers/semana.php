<?php
    class semana extends Controlador{

        public function __Construct(){            
            $this->ReporteModel = $this->modelo('ReporteModel');   
            if(!isset($_SESSION['sesion_active'])):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'APRENDIZ'):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'INSTRUCTOR'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
        }

        public function obtenerSemanaActual() {        
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $datos = [
                    'fecha' => trim($_POST['fecha'])                   
                ];
    
            echo json_encode($datos);      
            }    
           
          ;
        }


        public function insertPromedio() {     
            // Obtiene la fecha actual
            $fechaActual = new DateTime();
            $dia = $fechaActual->format('j');
            $ultimoDiaMes = (int)$fechaActual->format('t');

            // Obtiene el número de semana y el año para la fecha actual
            $numeroSemana = (int)$fechaActual->format('W');
            $ano = (int)$fechaActual->format('Y');

            // Obtiene el nombre del mes
            $nombreMes = $fechaActual->format('F');

            // Define un array con los nombres de las semanas
            $nombresSemanas = [
                "Primera",
                "Segunda",
                "Tercera",
                "Cuarta",
                "Quinta"
                // ... puedes continuar con más nombres de semanas si es necesario
            ];

            // Calcula el número de semana dentro del mes
            $fechaInicioMes = new DateTime($ano . '-' . $fechaActual->format('m') . '-01');
            $numeroSemanaMes = ceil(($dia + $fechaInicioMes->format('w')) / 7);
            $indiceSemana = ($numeroSemanaMes - 1) % count($nombresSemanas);

            // Obtiene el nombre de la semana actual
            $nombreSemana = $nombresSemanas[$indiceSemana];

            if ($nombreSemana == "Primera") {
                echo "Estamos en la Primera semana de $nombreMes, $ano.";   
                $resulset = $this->ReporteModel->SumaSemana1();             
            } elseif ($nombreSemana == "Segunda") {
                echo "Estamos en la Segunda semana de $nombreMes, $ano.";
                $resulset = $this->ReporteModel->SumaSemana2();
                echo json_encode ($resulset);                
            } elseif ($nombreSemana == "Tercera") {
                echo "Estamos en la Tercera semana de $nombreMes, $ano.";
                $resulset = $this->ReporteModel->SumaSemana3();
            } elseif ($nombreSemana == "Cuarta") {
                echo "Estamos en la Cuarta semana de $nombreMes, $ano.";
                $resulset = $this->ReporteModel->SumaSemana4();
            } else {
                echo "Estamos en la $nombreSemana semana de $nombreMes, $ano.";
            }

        }
        
        
        
    }
       
?>