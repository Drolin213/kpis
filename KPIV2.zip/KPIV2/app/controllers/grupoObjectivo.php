<?php
    class grupoObjectivo extends Controlador{

        public function __Construct(){
            $this->GrupoObjectivoModel = $this->modelo('GrupoObjectivoModel');
            $this->GruposModel = $this->modelo('GruposModel');
            $this->UsuarioModel = $this->modelo('UsuarioModel');
            
            $this->ReporteModel = $this->modelo('ReporteModel');
            if(!isset($_SESSION['sesion_active'])):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'APRENDIZ'):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'INSTRUCTOR'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
        }
       

        public function ListarObjectivo(){            
            $ListarObjectivo = $this->GrupoObjectivoModel->ListarObjectivo();
            $ListarObjectivoID = $this->GrupoObjectivoModel->ListarObjectivoID();
            $ListarGrupoPersonaID = $this->GrupoObjectivoModel->ListarGrupoPersonaID();
            $TipoGrupo = $this->GruposModel->ListarGrupo();
            $TipoPersona = $this->UsuarioModel->Listar();

            $datos = [
                'ListarObjectivo' => $ListarObjectivo,
                'ListarObjectivoID' => $ListarObjectivoID,
                'ListarGrupoPersonaID' => $ListarGrupoPersonaID,
                'TipoGrupo' => $TipoGrupo,
                'TipoPersona' => $TipoPersona
               
            ];
            $this->vista('objectivo/VistaObjectivo', $datos);
        }

        public function InsertarObjectivo(){
            $estado = '1';
           
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $datos = [
                    'Nombre' => trim($_POST["Nombre"]),
                    'Objetivo' => trim($_POST["Objetivo"]),
                    'Metrica' => trim($_POST["Metrica"]),
                    'Parametro' => trim($_POST["Parametro"]),
                    'Targetsemanal' => trim($_POST["Targetsemanal"]),  
                    'Targetmensual' => trim($_POST["Targetmensual"]),
                    'targetQ' => trim($_POST["targetQ"]),  
                    'Grupo' => trim($_POST["Grupo"]), 
                    'estado' => $estado, 
                ];   
                        
               //echo json_encode ($datos);
                
            } 
                
            $this->GrupoObjectivoModel->Insertar($datos);
            
        }
        public function InsertarObjectivoPersona(){
            $estado = '1';
           
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $datos = [
                    'Nombre' => trim($_POST["Nombres"]),
                    'Objetivo' => trim($_POST["Objetivos"]),
                    'Metrica' => trim($_POST["Metricas"]),
                    'Parametro' => trim($_POST["Parametros"]),
                    'Targetsemanal' => trim($_POST["Targetsemanals"]),  
                    'Targetmensual' => trim($_POST["Targetmensuals"]),
                    'targetQ' => trim($_POST["targetQs"]),                      
                    'estado' => $estado, 
                    'persona' => trim($_POST["personas"])
                ];   
                        
               //echo json_encode ($datos);
                
            } 
                
            $this->GrupoObjectivoModel->InsertarPersona($datos);
            
        }

        public function InsertarMeta(){           
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $datos = [
                    'Targetsemanal' => trim($_POST["Targetsemanal"]),  
                    'Targetmensual' => trim($_POST["Targetmensual"]),
                    'targetQ' => trim($_POST["targetQ"]),  
                   
                ];   
                        
               // echo json_encode ($datos);
                
            } 
                
            $this->GrupoObjectivoModel->Insertar($datos);
            
        }

        public function ToltalKpis(){
            $Listar = $this->GrupoObjectivoModel->ToltalKpis();
            
            echo json_encode($Listar->TOTAL); // Devuelve solo el valor 'TOTAL'
        }

        

    }
?>