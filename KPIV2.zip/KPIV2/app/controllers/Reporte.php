<?php
    class Reporte extends Controlador{

        public function __Construct(){
            $this->ReporteModel = $this->modelo('ReporteModel');
            if(!isset($_SESSION['sesion_active'])):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'APRENDIZ'):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'INSTRUCTOR'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
        }

        
        public function CrearReporte(){
            if(!isset($_SESSION['sesion_active'])){
                header('location:' . URL_SEE . 'Login/Logout');
            }else{
                $Listarpersona = $this->ReporteModel->ListarObjectivo();
                $ListarEvenct = $this->ReporteModel->ObtenerEventosPersona();
                $ListarObjectivoPersona = $this->ReporteModel->ListarObjectivoPersona();
               
                $datos = [
                    'Listarpersona' => $Listarpersona,
                    'ListarEvenct' => $ListarEvenct,
                    'ListarObjectivoPersona' => $ListarObjectivoPersona
                ];

               //echo json_encode($datos);
                $this->vista('configuracion/Reporte/ReporteTarget', $datos);
            } 
        }

        public function lost() {            
            $resulset = $this->ReporteModel->ListarID();
            // Carga la vista siempre, sin comprobar si $resulset está vacío o no es un arreglo           
            echo json_encode($resulset);
        }
    
    

        public function InsertarReporte() {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Recibe los datos JSON enviados desde el cliente                
                    $datos = [
                        'title' => trim($_POST['title']),
                        'start' => trim($_POST['start']),
                        'Dia' => trim($_POST['Dia']),
                        'personas' => trim($_POST['personas']),
                        'observacion' => trim($_POST['observacion']),
                        'semana' => trim($_POST['semana']),
                        'usuarioRED' => trim($_POST['usuarioRED']),
                        
                    ];
        
                //echo json_encode($datos);      
                $this->ReporteModel->InsertarReporte($datos);
                    
            }
        }
        
        public function EditarReporte(){            
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Recibe los datos JSON enviados desde el cliente
                $datosJSON = $_POST['editarEvent'];
                // Decodifica el JSON en un array asociativo
                $datosUsuario = json_decode($datosJSON, true);
                                
                echo json_encode($datosUsuario);
            }
        }
        

    }
?>