<?php
    class personaGrupo extends Controlador{

        public function __Construct(){
            $this->GrupoObjectivoModel = $this->modelo('GrupoObjectivoModel');
            $this->GruposModel = $this->modelo('GruposModel');
            $this->UsuarioModel = $this->modelo('UsuarioModel');
            
            $this->ReporteModel = $this->modelo('ReporteModel');
            if(!isset($_SESSION['sesion_active'])):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'APRENDIZ'):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'INSTRUCTOR'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
        }
       

        public function ListarpersonaGrupo(){            
            $TipoGrupo = $this->GruposModel->ListarGrupo();
            $ListarGrupoPersona = $this->GrupoObjectivoModel->ListarGrupoPersona();
            $datos = [                
                'TipoGrupo' => $TipoGrupo,
                'ListarGrupoPersona' => $ListarGrupoPersona
            ];
            $this->vista('configuracion/grupo/InsetarPersnaGrupo', $datos);
        }
        

        public function buscar($query) {
            $resultados = $this->GrupoObjectivoModel->buscarPersonas($query);
            foreach ($resultados as $resulset) {
                $datos[] = [
                    'ID' => $resulset->tbl_persona_USUARIO_RED,
                    'nombres' => $resulset->tbl_persona_NOMBRE,
                    'apellidos' => $resulset->tbl_persona_APELLIDO,
                    'usuarioRed' => $resulset->tbl_persona_USUARIO_RED,
                    'cargoTP' => $resulset->tbl_persona_CARGO,
                    'correoCorporativo' => $resulset->tbl_persona_CORREO_CORPORATIVO,
                    'centroCosto' => $resulset->tbl_persona_CENTRO_COSTO,
                    'direccion' => $resulset->tbl_persona_DIRECCION,
                    'fechaNacimiento' => $resulset->tbl_persona_FECHA_NACIMIENTO,
                    'numeroDocumento' => $resulset->tbl_persona_NUM_DOCUMENTO,
                    'numeroTelefono' => $resulset->tbl_persona_TELEFONO,
                    'ccmsId' => $resulset->tbl_persona_CCMS_ID,
                    'usuarioCCMS' => $resulset->tbl_persona_USUARIO_CCMS,
                    'fechaIngresoTP' => $resulset->tbl_persona_FECHA_INGRESO_TP,
                    'estadoCivil' => $resulset->tbl_persona_ESTDO_CIVIL,
                    'hijo' => $resulset->tbl_persona_HIJO,
                    'barrio' => $resulset->tbl_persona_BARRIO,
                    'ciudad' => $resulset->tbl_persona_CIUDAD,
                    'nombreInstitucion' => $resulset->tbl_persona_NOMBRE_INSTITUCION,
                    'Carrera' => $resulset->tbl_persona_CARRERA,
                    'tipoCarrera' => $resulset->tbl_persona_CARRERA,
                    'correoPersonal' => $resulset->tbl_persona_CORREO_PERSONAL,
                    'plaza' => $resulset->tbl_persona_PLAZA,
                    'grupoSanguinio' => $resulset->tbl_persona_GRUPO_SANGUINIO,
                    'afp' => $resulset->tbl_persona_AFP,
                    'equipoCompuesto' => $resulset->tbl_persona_EQUIPO_COMPUESTO,
                    'observaciones' => $resulset->tbl_persona_OBSERVACIONES
                                        
                ];
            }    
                // Devolver los resultados como respuesta
            echo json_encode($datos);
          
        }

        public function InsertarPersonaGrupo(){

        
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $datos = [
                    'Grupo' => trim($_POST['Grupo']),
                    'nombres' => trim($_POST['nombres']),
                ];
                
                
            }
            $this->GrupoObjectivoModel->Insertarpersonagrupo($datos);
        }

       
    }
?>