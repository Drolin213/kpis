<?php defined('BASEPATH') or exit('No se permite acceso directo');

	class Login extends Controlador {
		
		public function __construct(){
			$this->LoginModel = $this->modelo("LoginModel");
		}

		public function index(){
			$datos = [];
			$this->vista('login/index', $datos);
		}

		public function SigninAdministrador(){
			if (!isset($_SESSION['sesion_active'])) {
				if ($_SERVER['REQUEST_METHOD'] == 'POST') {
					$username = trim($_POST['ADMIN_USER']);
					$password = trim($_POST['ADMIN_PASS']);
					$resulset = $this->LoginModel->AutenticationAdministrador($username);
					if (isset($resulset)) {
						if ($resulset->PASSWORD == $password){
							$datos = [
								'username' => $resulset->tbl_usuarios_USUARIO,
								'tipo_usuario' => $resulset->CARGO
							];
							$_SESSION['sesion_active'] = $datos;
							$this->vista('home/redireccionar',$_SESSION['sesion_active']);							
						}
					} else {
						$this->vista('login/index', ['messageAdmin' => 'USUARIO O CONTRASEÑA INCORRECTOS']);
					}
				}
			} else {
				$this->vista('home/redireccionar');
			}			
		}


		public function SigninAprendiz(){
			if (!isset($_SESSION['sesion_active'])) :
				if($_SERVER['REQUEST_METHOD'] == 'POST'):
					$username = trim($_POST['STUDENT_USER']);
					$password = trim($_POST['STUDENT_PASS']);
					$resulset = $this->LoginModel->AutenticationAprendiz($username);
					if (isset($resulset)):
						if($resulset->PASSWORD == $password):
							$datos = [
								'ID' => $resulset->tbl_persona_USUARIO_RED,
								'correo' => $resulset->tbl_persona_CORREO,
								'password' => $resulset->PASSWORD,
								'cargoTP' => $resulset->tbl_persona_CARGO,
								'centroCosto' => $resulset->tbl_persona_CENTRO_COSTO,
								'nombres' => $resulset->tbl_persona_NOMBRE,
								'apellidos' => $resulset->tbl_persona_APELLIDO,
								'fechaNacimiento' => $resulset->tbl_persona_FECHA_NACIMIENTO,
								'numeroDocumento' => $resulset->tbl_persona_NUM_DOCUMENTO,
								'numeroTelefono' => $resulset->tbl_persona_TELEFONO,
								'ccmsId' => $resulset->tbl_persona_CCMS_ID,
								'usuarioCCMS' => $resulset->tbl_persona_USUARIO_CCMS,
								'fechaIngresoTP' => $resulset->tbl_persona_FECHA_INGRESO_TP,
								'correoCorporativo' => $resulset->tbl_persona_CORREO_CORPORATIVO,
								'estadoCivil' => $resulset->tbl_persona_ESTDO_CIVIL,
								'hijo' => $resulset->tbl_persona_HIJO,
								'direccion' => $resulset->tbl_persona_DIRECCION,
								'barrio' => $resulset->tbl_persona_BARRIO,
								'ciudad' => $resulset->tbl_persona_CIUDAD,
								'nombreInstitucion' => $resulset->tbl_persona_NOMBRE_INSTITUCION,
								'tipoCarrera' => $resulset->tbl_persona_CARRERA,
								'correoPersonal' => $resulset->tbl_persona_CORREO_PERSONAL,
								'plaza' => $resulset->tbl_persona_PLAZA,
								'grupoSanguinio' => $resulset->tbl_persona_GRUPO_SANGUINIO,
								'afp' => $resulset->tbl_persona_AFP,
								'equipoCompuesto' => $resulset->tbl_persona_EQUIPO_COMPUESTO,
								'observaciones' => $resulset->tbl_persona_OBSERVACIONES,
								'tipo_usuario' => $resulset->CARGO
							];
							$_SESSION['sesion_active'] = $datos;
							$this->vista('home/redireccionar',$_SESSION['sesion_active'] ['ID']);
						else:
							$this->vista('login/index', ['messageEstudent' => 'USUARIO O CONTRASEÑA INCORRECTOS']);
						endif;
					endif;
				endif;	
			else:
				$this->vista('home/redireccionar');
			endif;		
		}


		public function Logout(){
			unset($_SESSION['sesion_active']);
			$this->vista('login/index');
		}

	}