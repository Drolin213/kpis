<?php
    class perfil extends Controlador{

        public function __Construct(){
            $this->PerfilModel = $this->modelo('PerfilModel');
            
        }

        public function editProfile(){
            $ListarPersona = $this->PerfilModel->ListarPersona();
            $datos = ['ListarPersona' => $ListarPersona];       
            $this->vista('configuracion/perfil/DatosPerfil', $datos);
            
        }

        public function CargarDatos(){
            $idPersona = $_POST['idPersona'];
            $resulset = $this->PerfilModel->CargarDatos($idPersona);
            echo json_encode($resulset);
        }

        public function EditarDatosPersona(){
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $datos = [
                    'nombres' => $_POST['nombres'],
                    'apellidos' => $_POST['apellidos'],
                    'usuarioRed' => $_POST['usuarioRed'],
                    'cargoTP' => $_POST['cargoTP'],
                    'correoCorporativo' => $_POST['correoCorporativo'],
                    'centroCosto' => $_POST['centroCosto'],
                    'direccion' => $_POST['direccion'],
                    'fechaNacimiento' => $_POST['fechaNacimiento'],
                    'numeroDocumento' => $_POST['numeroDocumento'],
                    'numeroTelefono' => $_POST['numeroTelefono'],
                    'ccmsId' => $_POST['ccmsId'],
                    'usuarioCCMS' => $_POST['usuarioCCMS'],
                    'fechaIngresoTP' => $_POST['fechaIngresoTP'],
                    'estadoCivil' => $_POST['estadoCivil'],
                    'hijo' => $_POST['hijo'],
                    'barrio' => $_POST['barrio'],
                    'ciudad' => $_POST['ciudad'],
                    'nombreInstitucion' => $_POST['nombreInstitucion'],
                    'tipoCarrera' => $_POST['tipoCarrera'],
                    'correoPersonal' => $_POST['correoPersonal'],
                    'plaza' => $_POST['plaza'],
                    'grupoSanguinio' => $_POST['grupoSanguinio'],
                    'afp' => $_POST['afp'],
                    'equipoCompuesto' => $_POST['equipoCompuesto'],
                    'observaciones' => $_POST['observaciones']
                ];
                //echo json_encode($datos);
            
                $this->PerfilModel->EditarPersona($datos);
            }
        }
    



    }
?>