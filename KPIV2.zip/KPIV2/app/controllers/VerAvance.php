<?php
    class VerAvance extends Controlador{

        public function __Construct(){
            if(!isset($_SESSION['sesion_active'])):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'APRENDIZ'):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'INSTRUCTOR'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
        }

        public function Listar(){
            $this->vista('configuracion/Reporte/VerAvance');
        }
    }
?>