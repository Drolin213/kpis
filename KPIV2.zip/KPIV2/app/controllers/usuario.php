<?php
    class usuario extends Controlador{

        public function __Construct(){
            $this->UsuarioModel = $this->modelo('UsuarioModel');
            if(!isset($_SESSION['sesion_active'])):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'APRENDIZ'):
                header('location:' . URL_SEE . 'Login/Logout');
            elseif($_SESSION['sesion_active']['tipo_usuario'] == 'INSTRUCTOR'):
                header('location:' . URL_SEE . 'Login/Logout');
            endif; 
        }

        public function ListarUsuario(){
            $ListarUsuario = $this->UsuarioModel->ListarUsuario();
            $datos = ['ListarUsuario' => $ListarUsuario];
            $this->vista('configuracion/usuario/ListarUsuario', $datos);
        }

        public function CrearUsuario(){
            $this->vista('configuracion/usuario/CrearUsuario');
        }

      

        
        public function ValidaExistencia() {
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $datosJSON = $_POST['nombreUsuario'];
                    $datosUsuario = json_decode($datosJSON, true);
        
                    $respuesta = array();
        
                    foreach ($datosUsuario as $item) {
                        if (isset($item["nombreUsuario"])) {
                            $existe = $UsuarioModel->ValidaExistencia($item["nombreUsuario"]);
                            $respuesta[$item["nombreUsuario"]] = $existe;
                        }
                    }
        
                    echo json_encode($respuesta);
                }
        }
        
         

        public function InsertarUsuario(){
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                // Recibe los datos JSON enviados desde el cliente            
                $datos = [
                    'Usuariored' => trim($_POST['Usuariored']),
                    'Password' => trim($_POST['Password'])                            
                ];
                //echo json_encode($datos);                       
                $this->UsuarioModel->InsertarUsuarios($datos);       
            }
        }
        

        public function InsertarPersona(){
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                
                $datos = [
                    'Usuariored' => trim($_POST['Usuariored']),
                    'Nombre' => trim($_POST['Nombre']),
                    'Apellido' => trim($_POST['Apellido']) ,
                    'NumDocumencto' => trim($_POST['NumDocumencto']) ,                           
                ];
                
                //echo json_encode($datos);
                $this->UsuarioModel->InsertarPersona($datos);
                    
            }            
        }
    }
?>