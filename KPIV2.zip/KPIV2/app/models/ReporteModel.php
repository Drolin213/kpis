<?php
    class ReporteModel{
        private $db;

        public function __construct(){
            $this->db = new Base;
        }

        public function InsertarReporte($datos){
            $this->db->query('INSERT INTO tbl_dias (tbl_dias_ID, tbl_dias_FECHA, tbl_dias_META_DIA, tbl_dias_OBSERVACIONES_PERSONALES, tbl_dias_OBSERVACIONES, tbl_SEMANA, tbl_persona_USUARIO_RED) 
                            VALUES (:title, :start, :Dia, :personas, :observacion, :semana, :usuarioRED)');
            $this->db->bind(':title', $datos['title']);
            $this->db->bind(':start', $datos['start']);
            $this->db->bind(':Dia', $datos['Dia']);  
            $this->db->bind(':personas', $datos['personas']);  
            $this->db->bind(':observacion', $datos['observacion']); 
            $this->db->bind(':semana', $datos['semana']); 
            $this->db->bind(':usuarioRED', $datos['usuarioRED']); 
            ($this->db->execute()) ? true : false ;

        }

        public function ObtenerEventosPersona(){
            $this->db->query('SELECT * FROM tbl_dias WHERE tbl_persona_USUARIO_RED = :id ');            
            $this->db->bind(':id', $_SESSION['sesion_active']['ID']);
            return $this->db->registros();    
        }

        

        public function EditarReporte($datos){
            $this->db->query('UPDATE tbl_dias SET tbl_dias_FECHA =:start, tbl_dias_DIA_SEMANA =:diaSemana, tbl_dias_META =:Meta, tbl_dias_OBSERVACIONES =:Observacion, tbl_SEMANA =:semana WHERE tbl_dias_ID = :diaID');
            $this->db->bind(':diaID', $datos['diaID']);
            $this->db->bind(':start', $datos['start']);
            $this->db->bind(':diaSemana', $datos['diaSemana']);
            $this->db->bind(':Meta', $datos['Meta']);
            $this->db->bind(':Observacion', $datos['Observacion']);
            $this->db->bind(':semana', $datos['semana']);
            $this->db->bind(':usuarioRED', $datos['usuarioRED']);   
            ($this->db->execute()) ? true : false;
        }

        public function Insertar($datos){
            $this->db->query('INSERT INTO tbl_dias (tbl_dias_DIA_SEMANA, tbl_dias_META_MES, tbl_dias_META_DIA) 
                                VALUES ( :Targetsemanal, :Targetmensual, :targetQ, )');
            $this->db->bind(':Targetsemanal', $datos['Targetsemanal']);
            $this->db->bind(':Targetmensual', $datos['Targetmensual']);
            $this->db->bind(':targetQ', $datos['targetQ']);
            ($this->db->execute()) ? true : false ;

        }

        public function ListarID(){
            $this->db->query('SELECT tbl_grupo_objectivo_ID, tbl_grupo_objectivos_NOMBRES, tbl_grupo_objectivo_OBJETIVO FROM tbl_grupo_objectivo_usuario WHERE tbl_persona_USUARIO_RED = :id ');            
            $this->db->bind(':id', $_SESSION['sesion_active']['ID']);
            return $this->db->registros();    
        }
        

        public function ListarObjectivo(){
            $this->db->query('SELECT tbl_grupo_objectivo_ID, tbl_grupo_objectivos_NOMBRES, tbl_grupo_objectivo_OBJETIVO, tbl_persona_USUARIO_RED  FROM tbl_grupo_objectivo_usuario');
            return  $this->db->registros();
        }


        public function ListarObjectivoPersona(){
            $this->db->query('SELECT * FROM tbl_dias WHERE tbl_persona_USUARIO_RED = :id ');            
            $this->db->bind(':id', $_SESSION['sesion_active']['ID']);
            return $this->db->registros();    
        }

        

       
    }
?>