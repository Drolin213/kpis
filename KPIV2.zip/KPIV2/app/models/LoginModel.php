<?php
    class LoginModel {
      
        private $db;

        function __construct(){
           
          $this->db = new Base;
        }

        public function AutenticationAdministrador($username = ''){
          $this->db->query("SELECT tbl_usuarios_USUARIO, tbl_usuarios_CLAVE as PASSWORD, tbl_usuarios_CARGO as CARGO FROM tbl_usuarios  WHERE tbl_usuarios_USUARIO = :username");
          $this->db->bind(':username', $username);
          return $this->db->registro();
        }    

        public function AutenticationAprendiz($username = ''){
          $this->db->query( "SELECT p.tbl_persona_USUARIO_RED, u.tbl_usuarios_CLAVE AS PASSWORD, p.tbl_persona_NOMBRE, p.tbl_persona_APELLIDO, tbl_usuarios_CARGO as CARGO FROM tbl_persona p INNER JOIN tbl_usuarios u ON p.tbl_persona_USUARIO_RED = u.tbl_usuarios_USUARIO WHERE p.tbl_persona_NUM_DOCUMENTO = :username");
          $this->db->bind(':username', $username);
          return $this->db->registro();
        }
       
    }

    