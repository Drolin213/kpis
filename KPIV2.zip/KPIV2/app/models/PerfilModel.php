<?php
    class PerfilModel{
        private $db;

        public function __construct(){
            $this->db = new Base;
        }

        public function ListarPersona(){
            $this->db->query('SELECT * FROM tbl_persona');
            return $resultados = $this->db->registro();
        }

        public function CargarDatos($idPersona){
            $this->db->query("SELECT 
                    tbl_persona_USUARIO_RED AS tbl_persona_USUARIO_RED,
                    tbl_persona_CARGO AS tbl_persona_CARGO,
                    tbl_persona_CENTRO_COSTO AS tbl_persona_CENTRO_COSTO,
                    tbl_persona_NOMBRE AS tbl_persona_NOMBRE,
                    tbl_persona_APELLIDO AS tbl_persona_APELLIDO,
                    tbl_persona_FECHA_NACIMIENTO AS tbl_persona_FECHA_NACIMIENTO,
                    tbl_persona_NUM_DOCUMENTO AS tbl_persona_NUM_DOCUMENTO,
                    tbl_persona_TELEFONO AS tbl_persona_TELEFONO,
                    tbl_persona_CCMS_ID AS tbl_persona_CCMS_ID,
                    tbl_persona_USUARIO_CCMS AS tbl_persona_USUARIO_CCMS,
                    tbl_persona_FECHA_INGRESO_TP AS tbl_persona_FECHA_INGRESO_TP,
                    tbl_persona_CORREO_CORPORATIVO AS tbl_persona_CORREO_CORPORATIVO,
                    tbl_persona_ESTDO_CIVIL AS tbl_persona_ESTDO_CIVIL,
                    tbl_persona_HIJO AS tbl_persona_HIJO,
                    tbl_persona_DIRECCION AS tbl_persona_DIRECCION,
                    tbl_persona_BARRIO AS tbl_persona_BARRIO,
                    tbl_persona_CIUDAD AS tbl_persona_CIUDAD,
                    tbl_persona_NOMBRE_INSTITUCION AS tbl_persona_NOMBRE_INSTITUCION,
                    tbl_persona_CARRERA AS tbl_persona_CARRERA,
                    tbl_persona_TIPO_CARRERA AS tbl_persona_TIPO_CARRERA,
                    tbl_persona_NIVEL_CARRERA AS tbl_persona_NIVEL_CARRERA,
                    tbl_persona_CORREO_PERSONAL AS tbl_persona_CORREO_PERSONAL,
                    tbl_persona_PLAZA AS tbl_persona_PLAZA,
                    tbl_persona_GRUPO_SANGUINIO AS tbl_persona_GRUPO_SANGUINIO,
                    tbl_persona_AFP AS tbl_persona_AFP,
                    tbl_persona_EQUIPO_COMPUESTO AS tbl_persona_EQUIPO_COMPUESTO,
                    tbl_persona_OBSERVACIONES AS tbl_persona_OBSERVACIONES,
                    tbl_persona_ESTADO AS tbl_persona_ESTADO
                FROM tbl_persona
                WHERE tbl_persona_USUARIO_RED = :idPersona");
            $this->db->bind(':idPersona', $idPersona);
            $resultados = $this->db->registro();
            return $resultados;
        }

        public function EditarPersona($datos){
            $this->db->query('UPDATE tbl_persona SET tbl_persona_CARGO = :cargoTP, tbl_persona_CENTRO_COSTO = :centroCosto, tbl_persona_NOMBRE = :nombres, tbl_persona_APELLIDO = :apellidos, tbl_persona_FECHA_NACIMIENTO = :fechaNacimiento, tbl_persona_NUM_DOCUMENTO = :numeroDocumento, tbl_persona_TELEFONO = :numeroTelefono, tbl_persona_CCMS_ID = :ccmsId, tbl_persona_USUARIO_CCMS = :usuarioCCMS, tbl_persona_FECHA_INGRESO_TP = :fechaIngresoTP, tbl_persona_CORREO_CORPORATIVO = :correoCorporativo, tbl_persona_ESTDO_CIVIL = :estadoCivil, tbl_persona_HIJO = :hijo, tbl_persona_DIRECCION = :direccion, tbl_persona_BARRIO = :barrio, tbl_persona_CIUDAD = :ciudad, tbl_persona_NOMBRE_INSTITUCION = :nombreInstitucion, tbl_persona_CARRERA = :tipoCarrera, tbl_persona_TIPO_CARRERA = :tipoCarrera, tbl_persona_NIVEL_CARRERA = :nivelCarrera, tbl_persona_CORREO_PERSONAL = :correoPersonal, tbl_persona_PLAZA = :plaza, tbl_persona_GRUPO_SANGUINIO = :grupoSanguinio, tbl_persona_AFP = :afp, tbl_persona_EQUIPO_COMPUESTO = :equipoCompuesto,tbl_persona_OBSERVACIONES = :observaciones WHERE tbl_persona_USUARIO_RED = :usuarioRed');
            // Asignar valores a los parámetros
            $this->db->bind(':usuarioRed', $datos['usuarioRed']);
            $this->db->bind(':cargoTP', $datos['cargoTP']);
            $this->db->bind(':centroCosto', $datos['centroCosto']);
            $this->db->bind(':nombres', $datos['nombres']);
            $this->db->bind(':apellidos', $datos['apellidos']);
            $this->db->bind(':fechaNacimiento', $datos['fechaNacimiento']);
            $this->db->bind(':numeroDocumento', $datos['numeroDocumento']);
            $this->db->bind(':numeroTelefono', $datos['numeroTelefono']);
            $this->db->bind(':ccmsId', $datos['ccmsId']);
            $this->db->bind(':usuarioCCMS', $datos['usuarioCCMS']);
            $this->db->bind(':fechaIngresoTP', $datos['fechaIngresoTP']);
            $this->db->bind(':correoCorporativo', $datos['correoCorporativo']);
            $this->db->bind(':estadoCivil', $datos['estadoCivil']);
            $this->db->bind(':hijo', $datos['hijo']);
            $this->db->bind(':direccion', $datos['direccion']);
            $this->db->bind(':barrio', $datos['barrio']);
            $this->db->bind(':ciudad', $datos['ciudad']);
            $this->db->bind(':nombreInstitucion', $datos['nombreInstitucion']);
            $this->db->bind(':tipoCarrera', $datos['tipoCarrera']);
            $this->db->bind(':nivelCarrera', $datos['nivelCarrera']);
            $this->db->bind(':correoPersonal', $datos['correoPersonal']);
            $this->db->bind(':plaza', $datos['plaza']);
            $this->db->bind(':grupoSanguinio', $datos['grupoSanguinio']);
            $this->db->bind(':afp', $datos['afp']);
            $this->db->bind(':equipoCompuesto', $datos['equipoCompuesto']);
            $this->db->bind(':observaciones', $datos['observaciones']);
            ($this->db->execute()) ? true : false;
        }
       
    }
?>