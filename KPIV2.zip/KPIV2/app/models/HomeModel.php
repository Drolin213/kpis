<?php

    Class HomeModel{
        
        private $db;
        public function __construct(){
            $this->db = new Base();
        }

        public function TotalGrupo(){
            $this->db->query('SELECT COUNT(tbl_grupo_ID) as TOTAL FROM tbl_grupo');
            return $this->db->registro();
        }
 
        public function TotalUsuario(){
            $this->db->query('SELECT COUNT(tbl_persona_USUARIO_RED ) as TOTAL FROM tbl_persona');
            return $this->db->registro();
        }

        public function ToltalKpis(){
            $this->db->query('SELECT COUNT(tbl_grupo_objectivo_ID) as TOTAL FROM tbl_grupo_objectivo');
            return $this->db->registro();
        }


        public function ToltalDia(){
            $this->db->query('SELECT tbl_SEMANA FROM tbl_dias');
            return $this->db->registros();
        }
 
    }
?>