<?php
    class GrupoObjectivoModel{
        private $db;

        public function __construct(){
            $this->db = new Base;

        }

        public function ListarObjectivo(){
            $this->db->query('SELECT * FROM tbl_grupo_objectivo');            
            return $resultados = $this->db->registros();
        }
        
        public function ListarObjectivoID(){
            $this->db->query('SELECT * FROM tbl_grupo_objectivo WHERE tbl_grupo_ID = '.$_GET['id']);            
            return $resultados = $this->db->registros();    
        }

        public function Listar(){
            $this->db->query('SELECT COUNT(tbl_grupo_ID) FROM tbl_grupo');
            return $resultados = $this->db->registros();
        }

        public function Insertar($datos){
            $this->db->query('INSERT INTO tbl_grupo_objectivo (tbl_grupo_objectivo_ID, tbl_grupo_objectivos_NOMBRES, tbl_grupo_objectivo_OBJETIVO, tbl_grupo_objectivo_METRICA, tbl_grupo_objectivo_PARAMETRO, tbl_grupo_objectivo_OBJETIVO_SEMANA, tbl_grupo_objectivo_OBJETIVO_MESES, tbl_grupo_objectivo_PROMEDIO, tbl_grupo_objectivo_ESTADO, tbl_grupo_ID)  
                                VALUES (NUll, :Nombre, :Objetivo, :Metrica, :Parametro, :Targetsemanal, :Targetmensual, :targetQ, :Grupo, :estado)');
            $this->db->bind(':Nombre', $datos['Nombre']);
            $this->db->bind(':Objetivo', $datos['Objetivo']);
            $this->db->bind(':Metrica', $datos['Metrica']);
            $this->db->bind(':Parametro', $datos['Parametro']);
            $this->db->bind(':Targetsemanal', $datos['Targetsemanal']);
            $this->db->bind(':Targetmensual', $datos['Targetmensual']);
            $this->db->bind(':targetQ', $datos['targetQ']);
            $this->db->bind(':Grupo', $datos['Grupo']);
            $this->db->bind(':estado', $datos['estado']);
            ($this->db->execute()) ? true : false ;

        }

        public function InsertarPersona($datos){
            $this->db->query('INSERT INTO tbl_grupo_objectivo_usuario (tbl_grupo_objectivo_ID, tbl_grupo_objectivos_NOMBRES, tbl_grupo_objectivo_OBJETIVO, tbl_grupo_objectivo_METRICA, tbl_grupo_objectivo_PARAMETRO, tbl_grupo_objectivo_OBJETIVO_SEMANA, tbl_grupo_objectivo_OBJETIVO_MESES, tbl_grupo_objectivo_PROMEDIO, tbl_grupo_objectivo_ESTADO, tbl_persona_USUARIO_RED)
                                VALUES (NUll, :Nombre, :Objetivo, :Metrica, :Parametro, :Targetsemanal, :Targetmensual, :targetQ, :estado, :persona)');
            $this->db->bind(':Nombre', $datos['Nombre']);
            $this->db->bind(':Objetivo', $datos['Objetivo']);
            $this->db->bind(':Metrica', $datos['Metrica']);
            $this->db->bind(':Parametro', $datos['Parametro']);
            $this->db->bind(':Targetsemanal', $datos['Targetsemanal']);
            $this->db->bind(':Targetmensual', $datos['Targetmensual']);
            $this->db->bind(':targetQ', $datos['targetQ']);            
            $this->db->bind(':estado', $datos['estado']);
            $this->db->bind(':persona', $datos['persona']);
            ($this->db->execute()) ? true : false ;

        }

        public function ToltalKpis(){
            $this->db->query('SELECT COUNT(tbl_grupo_objectivo_ID) as TOTAL FROM tbl_grupo_objectivo');
            return $this->db->registro();
        }
        
        public function ListarGrupoPersonaID(){
            $this->db->query('SELECT p.tbl_persona_USUARIO_RED, p.tbl_persona_NOMBRE, p.tbl_persona_APELLIDO, g.tbl_grupo_NOMBRES, g.tbl_grupo_ID FROM tbl_persona p INNER JOIN tbl_persona_asinado_grupo pa ON p.tbl_persona_USUARIO_RED = pa.tbl_persona_USUARIO_RED INNER JOIN tbl_grupo g ON pa.tbl_grupo_ID = g.tbl_grupo_ID WHERE g.tbl_grupo_ID = '.$_GET['id']);            
            return $resultados = $this->db->registros();    
        }

        
        // para la vista de insertar persona a grupo 

        public function buscarPersonas($query) {
            $query = '%' . $query . '%'; // Agregamos los '%' al valor de búsqueda
            $this->db->query("SELECT tbl_persona_USUARIO_RED, tbl_persona_CARGO, tbl_persona_CENTRO_COSTO, tbl_persona_NOMBRE, tbl_persona_APELLIDO, tbl_persona_FECHA_NACIMIENTO, tbl_persona_NUM_DOCUMENTO, tbl_persona_TELEFONO, tbl_persona_CCMS_ID, tbl_persona_USUARIO_CCMS, tbl_persona_FECHA_INGRESO_TP, tbl_persona_FECHA_EGRESO_TP, tbl_persona_CORREO_CORPORATIVO, tbl_persona_ESTDO_CIVIL, tbl_persona_HIJO, tbl_persona_DIRECCION, tbl_persona_BARRIO, tbl_persona_CIUDAD, tbl_persona_NOMBRE_INSTITUCION, tbl_persona_CARRERA, tbl_persona_TIPO_CARRERA, tbl_persona_NIVEL_CARRERA, tbl_persona_CORREO_PERSONAL, tbl_persona_PLAZA, tbl_persona_GRUPO_SANGUINIO, tbl_persona_AFP, tbl_persona_EQUIPO_COMPUESTO, tbl_persona_OBSERVACIONES, tbl_persona_ESTADO FROM tbl_persona WHERE tbl_persona_USUARIO_RED LIKE :query OR tbl_persona_NOMBRE LIKE :query OR tbl_persona_APELLIDO LIKE :query OR tbl_persona_NUM_DOCUMENTO LIKE :query OR tbl_persona_TELEFONO LIKE :query and tbl_persona_ESTADO = 1");
            $this->db->bind(':query', $query);
            $resultados = $this->db->registros();
            return $resultados;
        }

        public function Insertarpersonagrupo($datos){
            $this->db->query('INSERT INTO tbl_persona_asinado_grupo (tbl_persona_USUARIO_RED, tbl_grupo_ID)
                            VALUES (:nombres, :Grupo)');
            $this->db->bind(':nombres', $datos['nombres']);
            $this->db->bind(':Grupo', $datos['Grupo']);
            ($this->db->execute()) ? true : false ;

        }

        public function ListarGrupoPersona(){
            $this->db->query('SELECT p.tbl_persona_USUARIO_RED, p.tbl_persona_NOMBRE, p.tbl_persona_APELLIDO, g.tbl_grupo_NOMBRES FROM tbl_persona p INNER JOIN tbl_persona_asinado_grupo pa ON p.tbl_persona_USUARIO_RED = pa.tbl_persona_USUARIO_RED INNER JOIN tbl_grupo g ON pa.tbl_grupo_ID = g.tbl_grupo_ID');            
            return $resultados = $this->db->registros();
        }
    }
?>