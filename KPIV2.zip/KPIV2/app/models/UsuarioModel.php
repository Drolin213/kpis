<?php
    class UsuarioModel{
        private $db;

        public function __construct(){
            $this->db = new Base;
        }
        
        public function Listar(){
            $this->db->query('SELECT * FROM tbl_persona');
            return $resultados = $this->db->registros();
        }

        public function ListarPersonaID(){
            $this->db->query('SELECT * FROM tbl_persona WHERE tbl_persona_USUARIO_RED = '.$_GET['id']);            
            return $resultados = $this->db->registro();    
        }

        public function ListarUsuario(){
            $this->db->query('SELECT p.tbl_persona_USUARIO_RED,
                                    u.tbl_usuarios_CLAVE,
                                    p.tbl_persona_CARGO,
                                    p.tbl_persona_CENTRO_COSTO,
                                    p.tbl_persona_NOMBRE,
                                    p.tbl_persona_APELLIDO,
                                    p.tbl_persona_FECHA_NACIMIENTO,
                                    p.tbl_persona_NUM_DOCUMENTO,
                                    p.tbl_persona_TELEFONO,
                                    p.tbl_persona_CCMS_ID,
                                    p.tbl_persona_USUARIO_CCMS,
                                    p.tbl_persona_FECHA_INGRESO_TP,
                                    p.tbl_persona_FECHA_EGRESO_TP,
                                    p.tbl_persona_CORREO_CORPORATIVO,
                                    p.tbl_persona_ESTDO_CIVIL,
                                    p.tbl_persona_HIJO,
                                    p.tbl_persona_DIRECCION,
                                    p.tbl_persona_BARRIO,
                                    p.tbl_persona_CIUDAD,
                                    p.tbl_persona_NOMBRE_INSTITUCION,
                                    p.tbl_persona_CARRERA,
                                    p.tbl_persona_TIPO_CARRERA,
                                    p.tbl_persona_NIVEL_CARRERA,
                                    p.tbl_persona_CORREO_PERSONAL,
                                    p.tbl_persona_PLAZA,
                                    p.tbl_persona_GRUPO_SANGUINIO,
                                    p.tbl_persona_AFP,
                                    p.tbl_persona_EQUIPO_COMPUESTO,
                                    p.tbl_persona_OBSERVACIONES,
                                    p.tbl_persona_ESTADO
                             FROM tbl_persona AS p
                            INNER JOIN tbl_usuarios AS u ON p.tbl_persona_USUARIO_RED = u.tbl_usuarios_USUARIO');
            return $resultados = $this->db->registros();
        }

        public function InsertarUsuarios($datos){
            $this->db->query('INSERT INTO tbl_usuarios (tbl_usuarios_USUARIO, tbl_usuarios_CLAVE)
                            VALUES (:Usuariored, :Password)');
            $this->db->bind(':Usuariored', $datos['Usuariored']);
            $this->db->bind(':Password', $datos['Password']);
            ($this->db->execute()) ? true : false ;

        }

        public function InsertarPersona($datos){
            $this->db->query('INSERT INTO tbl_persona (tbl_persona_USUARIO_RED, tbl_persona_NOMBRE, tbl_persona_APELLIDO, tbl_persona_NUM_DOCUMENTO)
                                        VALUES (:Usuariored, :Nombre, :Apellido, :NumDocumencto)');
            $this->db->bind(':Usuariored', $datos['Usuariored']);
            $this->db->bind(':Nombre', $datos['Nombre']); 
            $this->db->bind(':Apellido', $datos['Apellido']); 
            $this->db->bind(':NumDocumencto', $datos['NumDocumencto']);

            ($this->db->execute()) ? true : false ;

        }

        public function ValidaExistencia($nombreUsuario) {
            $this->db->query("SELECT tbl_usuarios_USUARIO FROM tbl_usuarios WHERE tbl_usuarios_USUARIO = :nombreUsuario");
            $this->db->bind(':nombreUsuario', $nombreUsuario);
            $this->db->execute();
    
            return $this->db->rowCount() > 0;
        }
       
    }
?>