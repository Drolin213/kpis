<?php
    class GruposModel{
        private $db;

        public function __construct(){
            $this->db = new Base;

        }

        public function ListarGrupo(){
            $this->db->query('SELECT * FROM tbl_grupo');
            return $resultados = $this->db->registros();
        }

        public function ValidaExistencia($numID){
            $this->db->query("SELECT * FROM tbl_grupo WHERE tbl_grupos_AREA = '$numID'");
            return $resultados = $this->db->registro();
        }

        public function Obtener($IdGrupo){
            $this->db->query('SELECT * FROM tbl_grupo WHERE tbl_grupo_ID = :IdGrupo' );
            $this->db->bind(':IdGrupo', $IdGrupo);
            $row = $this->db->registro();
            return $row;
        }

        public function Insertar($datos){
            $this->db->query('INSERT INTO tbl_grupo (tbl_grupo_ID, tbl_grupo_AREA, tbl_grupo_NOMBRES, tbl_grupo_DESCRICION, tbl_grupo_MANAGER, tbl_grupo_CREAR_FECHA, tbl_grupo_ESTADO)
                            VALUES (NULL, :area, :nombres, :description, :manager,  :create_fecha, :estado)');
            $this->db->bind(':area', $datos['area']);
            $this->db->bind(':nombres', $datos['nombres']);
            $this->db->bind(':manager', $datos['manager']);
            $this->db->bind(':description', $datos['description']);
            $this->db->bind(':create_fecha', $datos['create_fecha']);
            $this->db->bind(':estado', $datos['estado']);
            ($this->db->execute()) ? true : false ;

        }


        public function TotalGrupo(){
            $this->db->query('SELECT COUNT(tbl_grupo_ID) as TOTAL FROM tbl_grupo');
            return $this->db->registro();
        }
 
        public function TotalUsuario(){
            $this->db->query('SELECT COUNT(tbl_persona_USUARIO_RED ) as TOTAL FROM tbl_persona');
            return $this->db->registro();
        }
    }
?>            