<?php require_once "../app/views/template.php"; ?>

<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4>Dashboard</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Lexa</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="state-information d-none d-sm-block">
                        <div class="state-graph">
                            <div id="header-chart-1"><canvas
                                    style="display: inline-block; width: 101px; height: 32px; vertical-align: top;"
                                    width="101" height="32"></canvas></div>
                            <div class="info">Balance $ 2,317</div>
                        </div>
                        <div class="state-graph">
                            <div id="header-chart-2"><canvas
                                    style="display: inline-block; width: 101px; height: 32px; vertical-align: top;"
                                    width="101" height="32"></canvas></div>
                            <div class="info">Item Sold 1230</div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-4 col-sm-6">
                    <div class="card mini-stat bg-primary">
                        <div class="card-body mini-stat-img">
                            <div class="mini-stat-icon">
                                <i class="mdi mdi-cube-outline float-end"></i>
                            </div>
                            <div class="text-white">
                                <h6 class="text-uppercase mb-3 font-size-16 text-white">Persona</h6>
                                <h2 class="mb-4 text-white" id="usersNumber"></h2>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-sm-6">
                    <div class="card mini-stat bg-primary">
                        <div class="card-body mini-stat-img">
                            <div class="mini-stat-icon">
                                <i class="mdi mdi-buffer float-end"></i>
                            </div>
                            <div class="text-white">
                                <h6 class="text-uppercase mb-3 font-size-16 text-white">Grupos</h6>
                                <h2 class="mb-4 text-white" id="groupNumber"></h2>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-sm-6">
                    <div class="card mini-stat bg-primary">
                        <div class="card-body mini-stat-img">
                            <div class="mini-stat-icon">
                                <i class="mdi mdi-tag-text-outline float-end"></i>
                            </div>
                            <div class="text-white">
                                <h6 class="text-uppercase mb-3 font-size-16 text-white">KPIs</h6>
                                <h2 class="mb-4 text-white" id="kpisNumber"></h2>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- end row -->

            <div class="row">


                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Promedio de Mes</h4>
                            <canvas id="mes" width="10em" height="5em"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Promedio de Dias</h4>
                            <canvas id="dia" width="10em" height="5em"></canvas>
                        </div>
                    </div>
                </div>


            </div>


        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
</div>
<!--Morris Chart-->
<script src="<?php echo URL_SEE?>/libs/morris.js/morris.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/raphael/raphael.min.js"></script>

<script src="<?php echo URL_SEE?>/js/pages/dashboard.init.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
<script src="https://cdn.canvasjs.com/jquery.canvasjs.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.min.js"
    integrity="sha512-7U4rRB8aGAHGVad3u2jiC7GA5/1YhQcQjxKeaVms/bT66i3LVBMRcBI9KwABNWnxOSwulkuSXxZLGuyfvo7V1A=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">
$(document).ready(function() {

    ToltalGrupo();

    function ToltalGrupo() {
        $.ajax({
            url: '<?php echo URL_SEE ?>Home/ToltalGrupo', // Reemplaza con la ruta correcta a tu controlador PHP
            type: 'POST',
            // Especifica el tipo de datos esperado
        }).done(function(resp) {
            var total = resp;
            // La respuesta contiene los datos en formato JSON
            $("#groupNumber").text(total);
            //console.log("Total de grupos:", resp);
        })

    }

    Toltalusuario();

    function Toltalusuario() {
        $.ajax({
            url: '<?php echo URL_SEE ?>Home/Toltalusuario', // Reemplaza con la ruta correcta a tu controlador PHP
            type: 'POST',
            // Especifica el tipo de datos esperado
        }).done(function(resp) {
            var total = resp;
            // La respuesta contiene los datos en formato JSON
            $("#usersNumber").text(total);
            //console.log("Total de grupos:", resp);
        })

    }

    ToltalKpis();

    function ToltalKpis() {
        $.ajax({
            url: '<?php echo URL_SEE ?>Home/ToltalKpis', // Reemplaza con la ruta correcta a tu controlador PHP
            type: 'POST',
            // Especifica el tipo de datos esperado
        }).done(function(resp) {
            var total = resp;
            // La respuesta contiene los datos en formato JSON
            $("#kpisNumber").text(total);
            //console.log("Total de grupos:", resp);
        })
    }

    ToltalPromedioMes();

    function ToltalPromedioMes() {
        $.ajax({
            url: '<?php echo URL_SEE?>Home/ReporteDia',
            type: 'POST',
          
        }).done(function(resp3) {
            //var dataTiempoReal = JSON.parse(resp3);
            console.log(resp3)


        })
        
        // Obtener una referencia al elemento canvas del DOM
        var $grafica_satisfaccion = document.querySelector("#mes");
        // Pasaamos las etiquetas desde PHP
        const etiquetas_satisfaccion = ["", "O", "L", "A"];

        const datos1_satisfaccion = {
            label: "Muy insatisfecho",
            data: [3, 4,
                7
            ], // La data es un arreglo que debe tener la misma cantidad de valores que la cantidad de etiquetas
            backgroundColor: 'rgba(246, 0, 0, 0.53)', // Color de fondo
            borderColor: 'rgba(246, 0, 0, 1)', // Color del borde
            borderWidth: 1, // Ancho del borde
        };
        const datos2_satisfaccion = {
            label: "Insatisfecho",
            data: [10, 14,
                17
            ], // La data es un arreglo que debe tener la misma cantidad de valores que la cantidad de etiquetas
            backgroundColor: '#19a0e1', // Color de fondo
            borderColor: 'rgba(246, 0, 0, 1)', // Color del borde
            borderWidth: 1, // Ancho del borde
        };

        new Chart($grafica_satisfaccion, {
            type: "bar", // Tipo de gráfica
            data: {
                labels: etiquetas_satisfaccion,
                datasets: [
                    datos1_satisfaccion,
                    datos2_satisfaccion,
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'hOLA',
                },
                scales: {
                    y: {
                        stacked: true
                    },
                    xAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: "Tiempo en meses",
                            fontColor: "black"
                        }
                    }],
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: "Usuarios finales en %",
                            fontColor: "black"
                        }
                    }]
                }
            }
        });

    }

    ToltalPromedioDia();

    function ToltalPromedioDia() {
        // Obtener una referencia al elemento canvas del DOM
        // Obtener una referencia al elemento canvas del DOM
        var $grafica_satisfaccion = document.querySelector("#dia");
        // Pasaamos las etiquetas desde PHP


        const etiquetas_satisfaccion = ["H", "O", "L", "A"];

        const datos1_satisfaccion = {
            label: "Muy insatisfecho",
            data: [3, 4,
                7
            ], // La data es un arreglo que debe tener la misma cantidad de valores que la cantidad de etiquetas
            backgroundColor: 'rgba(246, 0, 0, 0.53)', // Color de fondo
            borderColor: 'rgba(246, 0, 0, 1)', // Color del borde
            borderWidth: 1, // Ancho del borde
        };
        const datos2_satisfaccion = {
            label: "Insatisfecho",
            data: [10, 14,
                17
            ], // La data es un arreglo que debe tener la misma cantidad de valores que la cantidad de etiquetas
            backgroundColor: '#19a0e1', // Color de fondo
            borderColor: 'rgba(246, 0, 0, 1)', // Color del borde
            borderWidth: 1, // Ancho del borde
        };

        new Chart($grafica_satisfaccion, {
            type: "line", // Tipo de gráfica
            data: {
                labels: etiquetas_satisfaccion,
                datasets: [
                    datos1_satisfaccion,
                ]
            },
            options: {
                title: {
                    display: true,
                    text: 'hOLA',
                },
                scales: {
                    y: {
                        stacked: true
                    },
                    xAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: "Tiempo en meses",
                            fontColor: "black"
                        }
                    }],
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: "Usuarios finales en %",
                            fontColor: "black"
                        }
                    }]
                }
            }
        });
    }
});
</script>