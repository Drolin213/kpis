<?php 
    require_once "../app/views/template.php";


?>
<h1>hola intrutoior</h1>