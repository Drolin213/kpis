<?php  require_once "../app/views/template.php"; ?>
<script>
    var user = "<?php echo $_SESSION['sesion_active']['tipo_usuario']?>";
    if(user == 'ADMINISTRADOR'){
        window.location.replace('<?php echo URL_SEE?>Home/Index');
    }else{
        if(user == 'T'){
            window.location.replace('<?php echo URL_SEE?>Home/dashboardAprendiz');
        }else{
            if(user == 'I'){
                window.location.replace('<?php echo URL_SEE?>Home/dashboardInstructor');
            }
        }
    }
</script>