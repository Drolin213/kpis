<?php require_once "../app/views/template.php"; ?>
<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg">
                    <div class="card text-white bg-info">
                        <div class="card-body">
                            <div class="col-md-8">
                                <h4 class="alert-heading">Bienvenido al Sistema control- KPIs
                                </h4>
                                <p>es una herramienta o sistema que se utiliza para supervisar y gestionar el progreso o el cambio en un valor específico en términos porcentuales. Estos sistemas son ampliamente utilizados en diversas aplicaciones para realizar un seguimiento de cambios, mejoras o métricas en relación con un punto de referencia o valor inicial.
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
        <!-- container-fluid -->
    </div>
</div>