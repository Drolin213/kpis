<?php
    if($_SESSION['sesion_active']['tipo_usuario'] == 'ADMINISTRADOR'):
?>

<div class="vertical-menu mm-active">
    <div id="sidebar-menu" class="mm-active">
        <ul class="metismenu list-unstyled mm-show" id="side-menu">
            <li class="mm-active">
                <a href="<?php echo URL_SEE?>Home/Index" class="waves-effect active" aria-expanded="false">
                    <i class="mdi mdi-view-dashboard"></i>
                    <span class="badge rounded-pill bg-primary float-end">2</span>
                    <span>Dashboard</span>
                </a>
            </li>

            <li>
                <a class="has-arrow waves-effect">
                    <i class="mdi mdi-email-outline"></i>
                    <span>Usuarios</span>
                </a>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo URL_SEE?>usuario/ListarUsuario">Usuario</a></li>
                </ul>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo URL_SEE?>usuario/CrearUsuario">Crear Usuario</a></li>
                </ul>
            </li>
        
            <li>
                <a class="has-arrow waves-effect">
                    <i class="mdi mdi-email-outline"></i>
                    <span>Integrantes</span>
                </a>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo URL_SEE?>grupo/ListarGrupo">Grupos</a></li>
                </ul>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo URL_SEE?>grupo/CrearGrupo">Crear Grupos</a></li>
                </ul>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo URL_SEE?>personaGrupo/ListarpersonaGrupo">Insetar Persna Grupo</a></li>
                </ul>
            </li>

           

        </ul>

    </div>
</div>

<?php
    endif;
?>