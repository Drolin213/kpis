<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu mm-active">
    <div id="sidebar-menu" class="mm-active">
        <ul class="metismenu list-unstyled mm-show" id="side-menu">
            <li class="menu-title">Aprediz</li>

            <li>
                <a href="<?php echo URL_SEE;?>perfil/editProfile" class=" waves-effect">
                    <i class="mdi mdi-email-outline"></i>
                    <span>Perfil</span>
                </a>
            
            </li>
            <li>
                <a class="has-arrow waves-effect">
                    <i class="mdi mdi-email-outline"></i>
                    <span>Reporte</span>
                </a>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo URL_SEE?>Reporte/CrearReporte">Hora de Usuario</a></li>
                </ul>
                <ul class="sub-menu mm-collapse" aria-expanded="false">
                    <li><a href="<?php echo URL_SEE?>VerAvance/Listar">Avance Meta</a></li>
                </ul>
               
            </li>
        </ul>
    </div>
</div>    

<!-- Left Sidebar End -->
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script>
    $(function() { // Shorthand for $(document).ready(function() { 
        $('.nav a').filter(function(){return this.href==location.href}).parent().addClass('active').siblings().removeClass('active')
        $('.nav li').click(function() { 
            $('.nav li').removeClass('active');  
            $(this).addClass('active'); 
        });
    });
</script>