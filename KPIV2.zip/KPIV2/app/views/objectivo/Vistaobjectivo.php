<?php require_once "../app/views/template.php"; ?>

<link rel="stylesheet" href="<?php echo URL_SEE?>/css/group-members.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<link href="<?php echo URL_SEE?>/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet"
    type="text/css">
<link href="<?php echo URL_SEE?>/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet"
    type="text/css">
<div class="main-content" id="result">
    <div class="page-content">

        <div class="container-fluid">
            <section id="listgroups" style="display: none;">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="page-title-box">
                            <h4>Grupos</h4>
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Grupos</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-xl-4 col-md-6">
                        <div class="card directory-card">
                            <div>
                                <div class="directory-bg text-center">
                                    <div class="directory-overlay">
                                        <img class="rounded-circle avatar-lg img-thumbnail"
                                            src="<?php echo URL_SEE?>/images/groups/groups 1.png"
                                            alt="Generic placeholder image">
                                    </div>
                                </div>

                                <div class="directory-content text-center p-4">
                                    <p class=" mt-4">Area</p>
                                    <h5 class="font-size-16">Nombre</h5>
                                    <h5 class="font-size-13">Manager</h5>

                                    <p class="text-muted">Descripcion</p>

                                    <ul class="social-links list-inline mb-0 mt-4">
                                        <li class="list-inline-item">
                                            <button onclick="loadDataGroup('1')" type="button"
                                                class="btn btn-outline-primary waves-effect waves-light">
                                                <i class="fa-solid fa-arrow-right"></i>
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

            <section id="opcionGroups" style="display: block;">
                <div class="col-sm-6 col-md-3 mt-4">


                    <!--  Modal content nuevo obejctivo - grupo -->
                    <div class="modal fade bs-new-kpi-modal-lg" tabindex="-1" role="dialog"
                        aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <i class="mdi mdi-arrow-right text-primary me-1"></i>
                                    <h5 class="font-size-14 mb-4" id="groupModalNewKpi"> Nuevo Objectivo - Grupo
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-hidden="true"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="col-lg-5">
                                        <div class="mt-4">
                                            <div id="alertModalNewKpi" style="display: none;">
                                                <div class="alert alert-success" role="alert">
                                                    <strong class="textAlert">
                                                        <p id="textAlertModalNewKpi">
                                                        </p>
                                                    </strong>
                                                </div>
                                            </div>


                                            <div class="mb-3">
                                                <label class="form-label" for="formrow-firstname-input">Nombre</label>
                                                <input type="text" class="form-control" id="Nombre">
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-email-input">Objetivo</label>
                                                        <input type="text" class="form-control" id="Objetivo">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-password-input">Metrica</label>
                                                        <input type="text" class="form-control" id="Metrica">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-email-input">Parametro</label>
                                                        <div class="col-md-10">
                                                            <select class="form-control" id="Parametro">
                                                                <option>SELECCIONAR...</option>
                                                                <option value="Tiempo">Tiempo</option>
                                                                <option value="Unidad">Unidad</option>
                                                                <option value="Valor">Valor</option>
                                                                <option value="Tamaño">Tamaño</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="formrow-password-input">Target
                                                            semanal</label>
                                                        <input type="text" class="form-control" id="Targetsemanal">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="formrow-password-input">Target
                                                            mensual</label>
                                                        <input type="text" class="form-control" id="Targetmensual">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="formrow-password-input">Target
                                                            Qn</label>
                                                        <input type="text" class="form-control" id="targetQ">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-email-input">Grupo</label>
                                                        <div class="col-md-10">
                                                            <select class="form-control" id="Grupo">
                                                                <option>SELECCIONAR...</option>
                                                                <?php foreach($datos['TipoGrupo'] as $TipoGrupo): ?>
                                                                <option
                                                                    data-tokens="<?php echo $TipoGrupo->tbl_grupo_NOMBRES?>"
                                                                    value="<?php echo $TipoGrupo->tbl_grupo_ID?>">
                                                                    <?php echo $TipoGrupo->tbl_grupo_NOMBRES?></option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="mt-4">
                                                <button type="button" id="Crear"
                                                    class="btn btn-primary">Agregar</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->
                    <!--  Modal content nuevo obejctivo - grupo -->
                    <div class="modal fade bs-new-kpipersona-modal-lg" tabindex="-1" role="dialog"
                        aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <i class="mdi mdi-arrow-right text-primary me-1"></i>
                                    <h5 class="font-size-14 mb-4" id="groupModalNewKpi"> Nuevo Objectivo - persona
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-hidden="true"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="col-lg-5">
                                        <div class="mt-4">
                                            <div id="alertModalNewKpi" style="display: none;">
                                                <div class="alert alert-success" role="alert">
                                                    <strong class="textAlert">
                                                        <p id="textAlertModalNewKpi">
                                                        </p>
                                                    </strong>
                                                </div>
                                            </div>


                                            <div class="mb-3">
                                                <label class="form-label" for="formrow-firstname-input">Nombre</label>
                                                <input type="text" class="form-control" id="Nombres">
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-email-input">Objetivo</label>
                                                        <input type="text" class="form-control" id="Objetivos">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-password-input">Metrica</label>
                                                        <input type="text" class="form-control" id="Metricas">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-email-input">Parametro</label>
                                                        <div class="col-md-10">
                                                            <select class="form-control" id="Parametros">
                                                                <option>SELECCIONAR...</option>
                                                                <option value="Tiempo">Tiempo</option>
                                                                <option value="Unidad">Unidad</option>
                                                                <option value="Valor">Valor</option>
                                                                <option value="Tamaño">Tamaño</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="formrow-password-input">Target
                                                            semanal</label>
                                                        <input type="text" class="form-control" id="Targetsemanals">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="formrow-password-input">Target
                                                            mensual</label>
                                                        <input type="text" class="form-control" id="Targetmensuals">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" for="formrow-password-input">Target
                                                            Qn</label>
                                                        <input type="text" class="form-control" id="targetQs">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label"
                                                            for="formrow-email-input">persona</label>
                                                        <div class="col-md-10">
                                                            <select class="form-control" id="personas">
                                                                <option>SELECCIONAR...</option>
                                                                <?php foreach($datos['TipoPersona'] as $TipoPersona): ?>
                                                                <option
                                                                    data-tokens="<?php echo $TipoPersona->tbl_persona_NOMBRE?>"
                                                                    value="<?php echo $TipoPersona->tbl_persona_USUARIO_RED?>">
                                                                    <?php echo $TipoPersona->tbl_persona_NOMBRE?>
                                                                    <?php echo $TipoPersona->tbl_persona_APELLIDO?>
                                                                </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="mt-4">
                                                <button type="button" id="Crearpersona"
                                                    class="btn btn-primary">Agregar</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="page-title-box">
                            <h4>Grupos</h4>
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a class="aClic" onclick="loadListGroup();">Grupos</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Integrantes</a></li>
                                <li class="breadcrumb-item active">KPIS</li>
                            </ol>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-3 col-sm-6">
                        <div class="card mini-stat bg-primary">
                            <div class="card-body mini-stat-img">
                                <div class="mini-stat-icon">
                                    <i class="fa-solid fa-people-group float-end"></i>
                                </div>
                                <div class="text-white">
                                    <h6 class="text-uppercase mb-3 font-size-16 text-white">Integrantes</h6>
                                    <h2 class="mb-4 text-white" id="membersNumber">0</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6">
                        <div class="card mini-stat bg-primary">
                            <div class="card-body mini-stat-img">
                                <div class="mini-stat-icon">
                                    <i class="fa-solid  fa-user float-end"></i>
                                </div>
                                <div class="text-white">
                                    <h6 class="text-uppercase mb-3 font-size-16 text-white">KPIS</h6>
                                    <h2 class="mb-4 text-white" id="kpisNumber">0</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="col-xl-3 col-lg-6" id="tableGroups">
                        <div class="card">
                            <div id="alertNewGroup" style="display: none;">
                                <div class="alert alert-success" role="alert">
                                    <strong class="textAlert">
                                        <p id="textAlertNotification">
                                        </p>
                                    </strong>

                                </div>
                            </div>
                            <div class="card-body">
                                <div class="session2row">
                                    <h4 class="card-title">Listado de integrantes.</h4>
                                </div>
                                <div class="table-responsive">
                                    <div id="resultListGroups_wrapper"
                                        class="dataTables_wrapper dt-bootstrap4 no-footer">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-6">
                                                <div class="dataTables_length" id="resultListGroups_length"><label>Show
                                                        <select name="resultListGroups_length"
                                                            aria-controls="resultListGroups"
                                                            class="custom-select custom-select-sm form-control form-control-sm">
                                                            <option value="10">10</option>
                                                            <option value="25">25</option>
                                                            <option value="50">50</option>
                                                            <option value="100">100</option>
                                                        </select> entries</label></div>
                                            </div>
                                            <div class="col-sm-12 col-md-6">
                                                <div id="resultListGroups_filter" class="dataTables_filter">
                                                    <label>Search:<input type="search"
                                                            class="form-control form-control-sm" placeholder=""
                                                            aria-controls="resultListGroups"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <table id="resultListGroups"
                                                    class="table table-bordered dt-responsive nowrap dataTable no-footer dtr-inline"
                                                    style="border-collapse: collapse; border-spacing: 0px; width: 100%;"
                                                    role="grid" aria-describedby="resultListGroups_info">
                                                    <thead>
                                                        <tr role="row">
                                                            <th class="sorting_asc" tabindex="0"
                                                                aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                                style="width: 95.4px;"
                                                                aria-label="Usuario: activate to sort column descending"
                                                                aria-sort="ascending">Usuario</th>
                                                            <th class="sorting" tabindex="0"
                                                                aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                                style="width: 109.4px;"
                                                                aria-label="Nombres: activate to sort column ascending">
                                                                Nombres</th>
                                                            <th class="sorting" tabindex="0"
                                                                aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                                style="width: 110.4px;"
                                                                aria-label="Apellidos: activate to sort column ascending">
                                                                Apellidos</th>
                                                            <th class="sorting" tabindex="0"
                                                                aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                                style="width: 87.4px;"
                                                                aria-label="Correo: activate to sort column ascending">
                                                                Grupo</th>
                                                            <th class="sorting" tabindex="0"
                                                                aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                                style="width: 87.4px;"
                                                                aria-label="Correo: activate to sort column ascending">
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="viewResultuserDataCreate">
                                                        <?php $contador = 1; foreach ($datos['ListarGrupoPersonaID'] as $ListarGrupoPersonaID): ?>
                                                        <tr>
                                                            <td><?php echo $ListarGrupoPersonaID->tbl_persona_USUARIO_RED?>
                                                            </td>
                                                            <td><?php echo $ListarGrupoPersonaID->tbl_persona_NOMBRE?>
                                                            </td>
                                                            <td><?php echo $ListarGrupoPersonaID->tbl_persona_APELLIDO?>
                                                            </td>
                                                            <td><?php echo $ListarGrupoPersonaID->tbl_grupo_NOMBRES?>
                                                            </td>

                                                            <?php if ($_SESSION['sesion_active']['tipo_usuario'] == 'ADMINISTRADOR') : ?>
                                                            <td>
                                                                <center>
                                                                    <cite title="Editar">
                                                                        <a class="btn btn-info btn-icon-split"
                                                                            href="<?php echo URL_SEE;?>Programa/EditarProgramas/<?php echo $ListarGrupoPersonaID->tbl_persona_USUARIO_RED;?>">
                                                                            <span class="icon text-white-55">
                                                                                <i class="fas fa-edit"></i>
                                                                            </span>
                                                                        </a>
                                                                    </cite>
                                                                    <cite title="Borrar">
                                                                        <a class="btn btn-danger btn-icon-split"
                                                                            href="<?php echo URL_SEE;?>Programa/EliminarProgramas/<?php echo $ListarGrupoPersonaID->tbl_persona_USUARIO_RED;?>">
                                                                            <span class="icon text-white-55">
                                                                                <i class="fas fa-trash"></i>
                                                                            </span>
                                                                        </a>
                                                                    </cite>
                                                                </center>
                                                            </td>
                                                            <?php  endif; ?>
                                                        </tr>
                                                        <?php endforeach; ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 col-md-5">
                                                <div class="dataTables_info" id="resultListGroups_info" role="status"
                                                    aria-live="polite">Showing 1 to 10 of 100 entries</div>
                                            </div>
                                            <div class="col-sm-12 col-md-7">
                                                <div class="dataTables_paginate paging_simple_numbers"
                                                    id="resultListGroups_paginate">
                                                    <ul class="pagination">
                                                        <li class="paginate_button page-item previous disabled"
                                                            id="resultListGroups_previous"><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="0"
                                                                tabindex="0" class="page-link">Previous</a></li>
                                                        <li class="paginate_button page-item active"><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="1"
                                                                tabindex="0" class="page-link">1</a></li>
                                                        <li class="paginate_button page-item "><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="2"
                                                                tabindex="0" class="page-link">2</a></li>
                                                        <li class="paginate_button page-item "><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="3"
                                                                tabindex="0" class="page-link">3</a></li>
                                                        <li class="paginate_button page-item "><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="4"
                                                                tabindex="0" class="page-link">4</a></li>
                                                        <li class="paginate_button page-item "><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="5"
                                                                tabindex="0" class="page-link">5</a></li>
                                                        <li class="paginate_button page-item disabled"
                                                            id="resultListGroups_ellipsis"><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="6"
                                                                tabindex="0" class="page-link">…</a></li>
                                                        <li class="paginate_button page-item "><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="7"
                                                                tabindex="0" class="page-link">10</a></li>
                                                        <li class="paginate_button page-item next"
                                                            id="resultListGroups_next"><a href="#"
                                                                aria-controls="resultListGroups" data-dt-idx="8"
                                                                tabindex="0" class="page-link">Next</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-6" id="tableKpis">
                        <div class="card">
                            <div class="card-body">
                                <div class="session2row">
                                    <h4 class="card-title">Listado de Objectivo.</h4>
                                    <div class="text-center-a">
                                        <button type="button" class="btn btn-primary waves-effect waves-light"
                                            data-bs-toggle="modal" data-bs-target=".bs-new-kpi-modal-lg">
                                            Crear Objectivo Grupo
                                        </button><br>


                                        <button type="button" class="btn btn-primary waves-effect waves-light"
                                            data-bs-toggle="modal" data-bs-target=".bs-new-kpipersona-modal-lg">
                                            Crear Objectivo Persona
                                        </button>
                                    </div>

                                </div>
                                <ol class="activity-feed mb-0" id="loadListKpis">
                                    <?php $contador = 1; foreach ($datos['ListarObjectivoID'] as $ListarObjectivoID): ?>
                                    <li class="feed-item">
                                        <div class="feed-item-list">
                                            <a id="nombreKpi">Nombre;
                                                <?php echo $ListarObjectivoID->tbl_grupo_objectivos_NOMBRES?></a>
                                            <span
                                                class="activity-text">-Objetivo:<?php echo $ListarObjectivoID->tbl_grupo_objectivo_OBJETIVO?></span>
                                            <span class="activity-text">-Metrica:
                                                <?php echo $ListarObjectivoID->tbl_grupo_objectivo_METRICA?></span>
                                            <span class="activity-text">-Target:
                                                <?php echo $ListarObjectivoID->tbl_grupo_objectivo_OBJETIVO_SEMANA?></span>
                                            <span class="activity-text">-Cumplimiento Qn:
                                                <?php echo $ListarObjectivoID->tbl_grupo_objectivo_PROMEDIO?></span>
                                        </div>
                                    </li>
                                    <?php endforeach; ?>
                                </ol>



                                <div class="text-center">
                                    <a href="#" class="btn btn-sm btn-primary">Load More</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </section>
        </div> <!-- container-fluid -->

    </div>
</div>
<!-- Incluye la biblioteca jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/dropzone/min/dropzone.min.js"></script>
<!-- Required datatable js -->
<script src="<?php echo URL_SEE?>/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<!-- Buttons examples -->
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/jszip/jszip.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<!-- Responsive examples -->
<script src="<?php echo URL_SEE?>/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script type="text/javascript">
$(document).ready(function() {

    document.getElementById("Crear").addEventListener('click', function() {
        Crear()
    });

    document.getElementById("Crearpersona").addEventListener('click', function() {
        Crearpersona()
    });

    function Crear() {
        var Nombre = $('#Nombre').val()
        var Objetivo = $('#Objetivo').val();
        var Metrica = $('#Metrica').val();
        var Parametro = $('#Parametro').val();
        var Targetsemanal = $('#Targetsemanal').val();
        var Targetmensual = $('#Targetmensual').val();
        var targetQ = $('#targetQ').val();
        var Grupo = $('#Grupo').val();

        if (Nombre == "" || Objetivo == "" || Metrica == "" || Parametro == "" || Targetsemanal == "" ||
            Targetmensual == "" || targetQ == "") {
            alert('El campo esta vacio')
        } else {

            $.ajax({
                url: '<?php echo URL_SEE ?>grupoObjectivo/InsertarObjectivo',
                type: 'POST',
                data: {
                    Nombre: Nombre,
                    Objetivo: Objetivo,
                    Metrica: Metrica,
                    Parametro: Parametro,
                    Targetsemanal: Targetsemanal,
                    Targetmensual: Targetmensual,
                    targetQ: targetQ,
                    Grupo: Grupo
                }
            }).done((respuesta) => {
                console.log(respuesta)
                //alert('La vaina se guardo')

                setTimeout(function() {
                    var currentURL = window.location.href;
                    var newURL = '<?php echo URL_SEE?>grupoObjectivo/ListarObjectivo?id=1';
                    window.location.replace(newURL);
                }, 1000);
            }).fail(function() {
                alert('no se guardo la vaina, implementar sweet alert')
            })

        }
    }

    function Crearpersona() {
        var Nombres = $('#Nombres').val()
        var Objetivos = $('#Objetivos').val();
        var Metricas = $('#Metricas').val();
        var Parametros = $('#Parametros').val();
        var Targetsemanals = $('#Targetsemanals').val();
        var Targetmensuals = $('#Targetmensuals').val();
        var targetQs = $('#targetQs').val();
        var personas = $('#personas').val();

        if (Nombres == "" || Objetivos == "" || Metricas == "" || Parametros == "" || Targetsemanals == "" ||
            Targetmensuals == "" || targetQs == "") {
            alert('El campo esta vacio')
        } else {

            $.ajax({
                url: '<?php echo URL_SEE ?>grupoObjectivo/InsertarObjectivoPersona',
                type: 'POST',
                data: {
                    Nombres: Nombres,
                    Objetivos: Objetivos,
                    Metricas: Metricas,
                    Parametros: Parametros,
                    Targetsemanals: Targetsemanals,
                    Targetmensuals: Targetmensuals,
                    targetQs: targetQs,
                    personas: personas
                }
            }).done((respuesta) => {
                console.log(respuesta)
                //alert('La vaina se guardo')
                setTimeout(function() {
                    var currentURL = window.location.href;
                    var newURL = '<?php echo URL_SEE?>grupoObjectivo/ListarObjectivo?id=1';
                    window.location.replace(newURL);
                }, 1000);

            }).fail(function() {
                alert('no se guardo la vaina, implementar sweet alert')
            })

        }
    }

    ToltalKpis();

    function ToltalKpis() {
        $.ajax({
            url: '<?php echo URL_SEE ?>grupoObjectivo/ToltalKpis', // Reemplaza con la ruta correcta a tu controlador PHP
            type: 'POST',
            // Especifica el tipo de datos esperado
        }).done(function(resp) {
            var total = resp;
            // La respuesta contiene los datos en formato JSON
            $("#kpisNumber").text(total);
            //console.log("Total de grupos:", resp);
        })
    }

    autocomleta();

    function autocomleta() {
        data = {}
        $.ajax({
            url: '<?php echo URL_SEE ?>', // Reemplaza 'ruta_del_controlador' con la URL correcta de tu controlador
            type: 'GET',
            dataType: 'json',
        }).done((respuesta) => {
            console.log(respuesta)

            data = $.map(function(index, elem) {
                return {
                    tbl_persona_USUARIO_RED: value.tbl_persona_USUARIO_RED
                };
            })

        })
    }
    $("#responsables").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: '<?php echo URL_SEE ?>grupoObjectivo/buscar',
                type: "GET",
                dataType: "json",
                data: {
                    search: request.term
                },
                success: function(data) {
                    response(data);
                }
            })
        }
    })


});
</script>