<?php require_once "../app/views/template.php"; ?>
<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4>Usuarios</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="card-title">Lista Usuario</h4>
                        

                        <div id="datatable_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="datatable_length"><label>Show <select name="datatable_length" aria-controls="datatable" class="custom-select custom-select-sm form-control form-control-sm form-select form-select-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="datatable_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="datatable"></label></div></div></div><div class="row"><div class="col-sm-12"><table id="datatable" class="table table-bordered dt-responsive nowrap dataTable no-footer dtr-inline" style="border-collapse: collapse; border-spacing: 0px; width: 100%;" role="grid" aria-describedby="datatable_info">
                           

                            <table class="table table-sm m-0">
                                <thead>
                                    <tr>
                                        <th>#</th>                                        
                                        <th>Usuario Red</th>
                                        <th>Cargo</th>                                        
                                        <th>CORREO corporativo</th>
                                        <th>Nombre</th>
                                        <th>Apellido</th>
                                        <th>Cedula</th>
                                        <th>Telefono</th>
                                        <th>Cuidad</th>
                                        <th>Correo personal</th>
                                        <th>Observaciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $contador = 1; foreach ($datos['ListarUsuario'] as $ListarUsuario): ?>
                                        <tr>
                                            <td><?php echo $contador++ ?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_USUARIO_RED?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_CARGO?></td>                                            
                                            <td><?php echo $ListarUsuario->tbl_persona_CORREO_CORPORATIVO?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_NOMBRE?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_APELLIDO?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_NUM_DOCUMENTO?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_TELEFONO?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_CIUDAD?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_CORREO_PERSONAL?></td>
                                            <td><?php echo $ListarUsuario->tbl_persona_OBSERVACIONES?></td>
                                            
                                            <?php if ($_SESSION['sesion_active']['tipo_usuario'] == 'ADMINISTRADOR') : ?>
                                            <td>
                                            <center>
                                                <cite title="Editar">
                                                    <a  class="btn btn-info btn-icon-split" href="<?php echo URL_SEE;?>Programa/EditarProgramas/<?php echo $ListarUsuario->tbl_programa_ID;?>">
                                                        <span class="icon text-white-55">
                                                            <i class="fas fa-edit"></i>
                                                        </span>
                                                    </a>
                                            </cite>
                                            <cite title="Borrar">
                                            <a  class="btn btn-danger btn-icon-split" href="<?php echo URL_SEE;?>Programa/EliminarProgramas/<?php echo $ListarUsuario->tbl_programa_ID;?>">
                                                    <span class="icon text-white-55">
                                                    <i class="fas fa-trash"></i>
                                                </span>
                                                </a>
                                            </cite>
                                            </center>
                                            </td>
                                            <?php  endif; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                          
                           
                        </table></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="datatable_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="datatable_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="datatable_previous"><a href="#" aria-controls="datatable" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="datatable" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item "><a href="#" aria-controls="datatable" data-dt-idx="2" tabindex="0" class="page-link">2</a></li><li class="paginate_button page-item "><a href="#" aria-controls="datatable" data-dt-idx="3" tabindex="0" class="page-link">3</a></li><li class="paginate_button page-item "><a href="#" aria-controls="datatable" data-dt-idx="4" tabindex="0" class="page-link">4</a></li><li class="paginate_button page-item "><a href="#" aria-controls="datatable" data-dt-idx="5" tabindex="0" class="page-link">5</a></li><li class="paginate_button page-item "><a href="#" aria-controls="datatable" data-dt-idx="6" tabindex="0" class="page-link">6</a></li><li class="paginate_button page-item next" id="datatable_next"><a href="#" aria-controls="datatable" data-dt-idx="7" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

            <!-- container-fluid -->

    </div>
</div>
</div>
<script>
var timer = setTimeout(function() {
    $("#Message").fadeOut(1500);
}, 2000);
</script>