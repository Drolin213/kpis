<?php require_once "../app/views/template.php"; ?>
<div class="main-content" id="result">
    <link href="<?php echo URL_SEE?>/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css">
    <!-- DataTables -->
    <link href="<?php echo URL_SEE?>/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet"
        type="text/css">
    <link href="<?php echo URL_SEE?>/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet"
        type="text/css">


    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4>Crear nuevos usuarios</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Administrador</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Usuarios</a></li>
                            <li class="breadcrumb-item active">Crear</li>
                        </ol>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Subir excel</h4>

                            <p class="card-title-desc">
                                Se debe de cargar todos los datos nombrados en el archivo, si no tiene la plantilla la
                                puede descargar:
                                <a class="btn btn-primary waves-effect waves-light"
                                    href="<?php echo URL_SEE?>/public/documencto/RegisterUsers.xlsx" download>AQUI!!</a>

                        </div>

                        <div>
                            <div enctype="multipart/form-data" class="dropzone">

                                <div class="dz-message needsclick">


                                    <div class="mb-3">
                                        <i class="mdi mdi-cloud-upload-outline text-muted display-4"></i>
                                    </div>

                                    <div class="fallback">
                                        <input type="file" id="archivoInput" accept=".xlsx">

                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="text-center mt-4">
                            <button id="cargarBtn" type="button" class="btn btn-primary waves-effect waves-light"
                                disabled>Cargar en Tabla</button>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Visualizador de usuarios cargados</h4>
                        <p class="card-title-desc">
                            Por favor, asegúrese de verificar que toda la información esté correcta y de que no haya
                            ningún dato vacío.
                        </p>
                        <div id="paginacion"></div>

                        <div class="table-responsive">
                            <div id="datatable_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="dataTables_length" id="datatable_length"><label>Show <select
                                                    name="datatable_length" aria-controls="datatable"
                                                    class="custom-select custom-select-sm form-control form-control-sm">
                                                    <option value="10">10</option>
                                                    <option value="25">25</option>
                                                    <option value="50">50</option>
                                                    <option value="100">100</option>
                                                </select> entries</label></div>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <div id="datatable_filter" class="dataTables_filter"><label>Search:<input
                                                    type="search" class="form-control form-control-sm" placeholder=""
                                                    aria-controls="datatable"></label></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table id="tablaDatos"
                                            class="table table-bordered dt-responsive nowrap dataTable no-footer dtr-inline"
                                            style="border-collapse: collapse; border-spacing: 0px; width: 100%;"
                                            role="grid" aria-describedby="datatable_info">
                                            <thead>
                                                <tr role="row">

                                                </tr>
                                            </thead>
                                            <tbody id="ViewUserData">
                                                <tr class="odd">
                                                    <td valign="top" colspan="5" class="dataTables_empty">No data
                                                        available in table</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 col-md-5">
                                        <div class="dataTables_info" id="datatable_info" role="status"
                                            aria-live="polite">Showing 0 to 0 of 0 entries</div>
                                    </div>
                                    <div class="col-sm-12 col-md-7">
                                        <div class="dataTables_paginate paging_simple_numbers" id="datatable_paginate">
                                            <ul class="pagination">
                                                <li class="paginate_button page-item previous disabled"
                                                    id="datatable_previous"><a href="#" aria-controls="datatable"
                                                        data-dt-idx="0" tabindex="0" class="page-link">Previous</a>
                                                </li>
                                                <li class="paginate_button page-item next disabled" id="datatable_next">
                                                    <a href="#" aria-controls="datatable" data-dt-idx="1" tabindex="0"
                                                        class="page-link">Next</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="button-items">
                            <button id="validateUsersCreate" type="button"
                                class="btn btn-secondary waves-effect waves-light">
                                Crear usuarios
                            </button>
                        </div>


                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>


        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Visualizador de usuarios con algun error</h4>
                        <p class="card-title-desc">
                            Por favor, asegúrese de verificar que toda la información esté correcta y de que no haya
                            ningún dato vacío.
                        </p>

                        <div class="table-responsive">
                            <table class="table table-bordered dt-responsive nowrap"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                    <tr>

                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>

                        </div>

                        <div class="button-items">
                            <button id="" type="button" class="btn btn-secondary waves-effect waves-light">
                                Usuarios validados
                            </button>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div> <!-- container-fluid -->

</div>
</div>

<!-- Agrega la biblioteca jQuery antes que cualquier otro script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/dropzone/min/dropzone.min.js"></script>
<!-- Agrega DataTables y sus dependencias -->
<script src="<?php echo URL_SEE?>/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/jszip/jszip.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/pdfmake/build/pdfmake.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/pdfmake/build/vfs_fonts.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo URL_SEE?>/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>




<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.5/xlsx.full.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {

    document.getElementById("validateUsersCreate").addEventListener('click', function() {
        validateUsersCreate()
    });



    $('#archivoInput').change(function(event) {
        archivoSeleccionado = event.target.files[0];
        // Habilitar el botón de carga una vez que se haya seleccionado un archivo
        $('#cargarBtn').prop('disabled', archivoSeleccionado ? false : true);
    });

    var archivoSeleccionado = null;

    $('#cargarBtn').click(function() {
        if (archivoSeleccionado) {
            var lector = new FileReader();

            lector.onload = function(e) {
                var contenido = e.target.result;
                var datos = XLSX.read(contenido, {
                    type: 'binary'
                });

                // Suponemos que el archivo Excel tiene una sola hoja (sheet)
                var hoja = datos.Sheets[datos.SheetNames[0]];
                var tabla = $('#tablaDatos tbody');
                tabla.empty(); // Limpiar la tabla antes de cargar los datos

                var range = XLSX.utils.decode_range(hoja['!ref']);

                // Procesar cabeceras de columnas (primera fila)
                var cabeceras = [];
                for (var columna = range.s.c; columna <= range.e.c; columna++) {
                    var celda = hoja[XLSX.utils.encode_cell({
                        r: range.s.r,
                        c: columna
                    })];
                    cabeceras.push(celda ? celda.v : '');
                }

                // Agregar las cabeceras a la tabla
                var cabecerasHTML = '<tr>';
                cabeceras.forEach(function(cabecera) {
                    cabecerasHTML += '<th>' + cabecera + '</th>';
                });
                cabecerasHTML += '</tr>';
                $('#tablaDatos thead').html(cabecerasHTML);

                // Procesar datos (filas)
                for (var fila = range.s.r + 1; fila <= range.e.r; fila++) {
                    var filaDatos = hoja[XLSX.utils.encode_row(fila)];
                    var filaHTML = '<tr>';
                    var filaVacia = true; // Variable para detectar filas vacías

                    for (var columna = range.s.c; columna <= range.e.c; columna++) {
                        var celdaDatos = hoja[XLSX.utils.encode_cell({
                            r: fila,
                            c: columna
                        })];

                        // Verificar si la celda contiene datos
                        var valorCelda = celdaDatos ? celdaDatos.v : '';
                        if (valorCelda !== '') {
                            filaVacia = false; // La fila no está vacía
                        }

                        filaHTML += '<td>' + valorCelda + '</td>';
                    }

                    if (!filaVacia) {
                        filaHTML += '</tr>';
                        tabla.append(filaHTML);
                    }
                }
            };

            lector.readAsBinaryString(archivoSeleccionado);
        }
    });

    function validateUsersCreate() {
        var datosUsuario = [];
        var datosPersona = [];
        var tododatos = [];

        // Recorremos las filas de la tabla a partir de la segunda fila (índice 1)
        $("#tablaDatos tbody tr:gt(0)").each(function() {
            var fila = $(this);
            var Usuariored = fila.find("td:eq(0)").text();
            var Password = fila.find("td:eq(1)").text();
            var Nombre = fila.find("td:eq(2)").text();
            var Apellido = fila.find("td:eq(3)").text();
            var NumDocumencto = fila.find("td:eq(4)").text();


            // Creamos un objeto con los datos de cada fila para Nombre, Cargo y Password
            var persona = {
                Usuariored: Usuariored,
                Nombre: Nombre,
                Apellido: Apellido,
                NumDocumencto: NumDocumencto
            };

            // Creamos un objeto con los datos de cada fila para Nombre y Correo
            var usuario = {
                Usuariored: Usuariored,
                Password: Password,

            };

            // Agregamos los objetos a los respectivos arrays
            datosUsuario.push(usuario);
            datosPersona.push(persona);
            tododatos.push(Usuariored);

        });

        // Verificar si hay datos antes de continuar
        if (tododatos.length > 0) {
            // Verificar la disponibilidad de todos los nombres de usuario
            $.ajax({
                type: "POST",
                url: '<?php echo URL_SEE ?>/usuario/ValidaExistencia', // Reemplaza 'URL_DE_TU_SERVIDOR' con la URL correcta
                data: {
                    nombreUsuario: JSON.stringify(tododatos)
                },
                success: function(respuesta) {
                    var data = JSON.parse(respuesta);

                    // Iterar a través de los resultados
                    for (var i = 0; i < tododatos.length; i++) {
                        var nombreUsuario = tododatos[i];
                        var existe = data[nombreUsuario];
                        if (existe) {
                            alert(nombreUsuario + ' el Usuario ya se encuentra registrado');
                        } else {
                            // Llama a la función para crear el usuario si no existe
                            crearUsuario(datosUsuario[i], datosPersona[i]);
                        }
                    }
                },
                error: function() {
                    console.log('Error al verificar el nombre de usuario.');
                }
            });
        } else {
            console.log("No se encontraron datos para procesar.");
        }
    }

    // Función para crear un usuario en el servidor
    function crearUsuario(datosUsuario, datosPersona) {         
        // Enviar los datos de Nombre, Cargo y Password al servidor mediante AJAX
        var usuariored = datosUsuario.Usuariored
        var Password = datosUsuario.Password

        // Enviar los datos de Nombre, Cargo y Password al servidor mediante AJAX
        var Usuariored = datosPersona.Usuariored
        var Nombre = datosPersona.Nombre
        var Apellido = datosPersona.Apellido
        var NumDocumencto = datosPersona.NumDocumencto

        $.ajax({
            type: "POST",
            url: '<?php echo URL_SEE ?>usuario/InsertarUsuario',
            data: {
                Usuariored: usuariored,
                Password: Password
            }
        }).done(function(respuesta) {
            console.log(respuesta);
            //console.log('Datos de Nombre y Password guardados correctamente');
        }).fail(function() {
            console.log('No se guardaron los datos de Nombre, Cargo y Password');
        });


        // Enviar los datos de Nombre y Correo al servidor mediante AJAX
        $.ajax({
            type: "POST",
            url: '<?php echo URL_SEE ?>usuario/InsertarPersona',
            data: {
                Usuariored: Usuariored,
                Nombre: Nombre,
                Apellido: Apellido,
                NumDocumencto: NumDocumencto
            }
        }).done(function(respuesta) {
            console.log(respuesta);
            //console.log('Datos de Nombre, Cargo y Correo guardados correctamente');
        }).fail(function() {
            console.log('No se guardaron los datos de Nombre y Correo');
        });
    }

});
</script>