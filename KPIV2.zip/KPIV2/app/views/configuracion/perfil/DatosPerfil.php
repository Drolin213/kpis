<?php require_once "../app/views/template.php"; ?>

<!-- CSS Files -->
<link href="<?php echo URL_SEE;?>MATERIAL_THEME/assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
<!-- CSS Just for demo purpose, don't include it in your project -->

<div class="main-content" id="result">
    <div class="container-fluid">
        <div class="content">
            <div class="row">
                <div class="col-md-4">
                    <div class="card card-user">
                        <div class="image">
                            <img src="<?php echo URL_SEE;?>MATERIAL_THEME/assets/img/damir-bosnjak.jpg" alt="..."
                                style="width: 32em;">
                        </div>
                        <div class="card-body">
                            <div class="author">
                                <a href="">
                                    <img class="avatar border-gray"
                                        src="<?php echo URL_SEE;?>MATERIAL_THEME/assets/img/mike.jpg" alt="...">
                                    <h5 class="title" id="titulo"></h5>
                                    <h5 class="title" id="titul"></h5>
                                    
                                </a>

                            </div>
                        </div>


                        <div class="card-footer">
                            <hr>

                        </div>
                    </div>

                </div>
                <div class="col-md-8">
                    <div class="card card-user">
                        <div class="card-header">
                            <h5 class="card-title">Edit Profile</h5>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="row">
                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="nombres">Nombres</label>
                                            <input type="text" id="nombres" class="form-control" placeholder="Company"
                                                value="">
                                        </div>
                                    </div>
                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="apellidos">Apellidos</label>
                                            <input type="text" id="apellidos" class="form-control"
                                                placeholder="Last Name" value="">
                                        </div>
                                    </div>
                                    <div class="col-md-4 pL-1">
                                        <div class="form-group">
                                            <label for="usuarioRed">Usuario Red</label>
                                            <input type="text" id="usuarioRed" class="form-control"
                                                placeholder="Username" value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="cargoTP">Cargo TP</label>
                                            <input type="text" id="cargoTP" class="form-control" placeholder="Cargo TP"
                                                value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="correoCorporativo">Correo Corporativo</label>
                                            <input type="email" id="correoCorporativo" class="form-control"
                                                placeholder="Email" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="centroCosto">Centro de Costo</label>
                                            <input type="text" id="centroCosto" class="form-control" placeholder="Email"
                                                value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="direccion">Direccion</label>
                                            <input type="text" id="direccion" class="form-control"
                                                placeholder="Direccion" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="fechaNacimiento">Fecha de Nacimiento</label>
                                            <input type="date" id="fechaNacimiento" class="form-control"
                                                placeholder="Fecha de Nacimiento" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 px-1">
                                        <div class="form-group">
                                            <label for="numeroDocumento">Numero Documento</label>
                                            <input type="number" id="numeroDocumento" class="form-control"
                                                placeholder="Numero Documento" value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="numeroTelefono">Numero Telefono</label>
                                            <input type="number" id="numeroTelefono" class="form-control"
                                                placeholder="Numero Telefono" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="ccmsId">CCMS_ID</label>
                                            <input type="text" id="ccmsId" class="form-control" placeholder="CCMS_ID"
                                                value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 px-1">
                                        <div class="form-group">
                                            <label for="usuarioCCMS">Usuario CCMS</label>
                                            <input type="text" id="usuarioCCMS" class="form-control"
                                                placeholder="Usuario CCMS" value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="fechaIngresoTP">Fecha de Ingreso TP</label>
                                            <input type="date" id="fechaIngresoTP" class="form-control"
                                                placeholder="Fecha de Ingreso TP" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="estadoCivil">Estado Civil</label>
                                            <input type="text" id="estadoCivil" class="form-control"
                                                placeholder="Estado Civil" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 px-1">
                                        <div class="form-group">
                                            <label for="hijo">Hijo</label>
                                            <input type="text" id="hijo" class="form-control" placeholder="Hijo"
                                                value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="barrio">Barrio</label>
                                            <input type="text" id="barrio" class="form-control" placeholder="Barrio"
                                                value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="ciudad">Ciudad</label>
                                            <input type="text" id="ciudad" class="form-control" placeholder="Ciudad"
                                                value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 px-1">
                                        <div class="form-group">
                                            <label for="nombreInstitucion">Nombre de Institución</label>
                                            <input type="text" id="nombreInstitucion" class="form-control"
                                                placeholder="Nombre de Institución" value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="carrera">Carrera</label>
                                            <input type="text" id="carrera" class="form-control" placeholder="Carrera"
                                                value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="tipoCarrera">Tipo de Carrera</label>
                                            <input type="text" id="tipoCarrera" class="form-control"
                                                placeholder="Tipo de Carrera" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 px-1">
                                        <div class="form-group">
                                            <label for="nivelCarrera">Nivel de Carrera</label>
                                            <input type="text" id="nivelCarrera" class="form-control"
                                                placeholder="Nivel de Carrera" value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="correoPersonal">Correo Personal</label>
                                            <input type="email" id="correoPersonal" class="form-control"
                                                placeholder="Correo Personal" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="plaza">Plaza</label>
                                            <input type="text" id="plaza" class="form-control" placeholder="Plaza"
                                                value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 px-1">
                                        <div class="form-group">
                                            <label for="grupoSanguinio">Grupo Sanguíneo</label>
                                            <input type="text" id="grupoSanguinio" class="form-control"
                                                placeholder="Grupo Sanguíneo" value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 pl-1">
                                        <div class="form-group">
                                            <label for="afp">AFP</label>
                                            <input type="text" id="afp" class="form-control" placeholder="AFP" value="">
                                        </div>
                                    </div>

                                    <div class="col-md-4 pr-1">
                                        <div class="form-group">
                                            <label for="equipoCompuesto">Equipo Compuesto</label>
                                            <input type="text" id="equipoCompuesto" class="form-control"
                                                placeholder="Equipo Compuesto" value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="observaciones">Observaciones</label>
                                            <textarea id="observaciones" class="form-control textarea"
                                                placeholder="Oh so, your weak rhyme You doubt I'll bother, reading into it"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <br>
                                <div class="row">
                                    <div class="update ml-auto mr-auto">
                                        <button type="submit" id="Crear" class="btn btn-primary btn-round">Update
                                            Profile</button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->

<!-- Agrega jQuery a tu página (asegúrate de cargarlo antes de este script) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<link href="<?php echo URL_SEE;?>css/sweetalert2.min.css" rel="stylesheet">

<script>
$(document).ready(function() {

    document.getElementById("Crear").addEventListener('click', function() {
        Crear()
    });


    function CargarDatos() {
        var tipoUsuario = '<?php echo $_SESSION['sesion_active']['tipo_usuario']?>';

        if (tipoUsuario == 'T') {
            var idPersona = '<?php echo $_SESSION['sesion_active']['ID']?>';
            $.ajax({
                url: '<?php echo URL_SEE?>perfil/CargarDatos',
                type: 'POST',
                data: {
                    idPersona: idPersona
                }
            }).done((res) => {
                var data = JSON.parse(res); // Agrega esto para verificar la respuesta en la consola

                // Llena los campos del formulario con los datos del usuario
                $('#titulo').text(data['tbl_persona_NOMBRE']);
                $('#titul').text(data['tbl_persona_APELLIDO']);
                $('#nombres').val(data['tbl_persona_NOMBRE']);
                $('#apellidos').val(data['tbl_persona_APELLIDO']);
                $('#usuarioRed').val(data['tbl_persona_USUARIO_RED']);
                $('#cargoTP').val(data['tbl_persona_CARGO']);
                $('#correoCorporativo').val(data['tbl_persona_CORREO_CORPORATIVO']);
                $('#centroCosto').val(data['tbl_persona_CENTRO_COSTO']);
                $('#direccion').val(data['tbl_persona_DIRECCION']);
                $('#fechaNacimiento').val(data['tbl_persona_FECHA_NACIMIENTO']);
                $('#numeroDocumento').val(data['tbl_persona_NUM_DOCUMENTO']);
                $('#numeroTelefono').val(data['tbl_persona_TELEFONO']);
                $('#ccmsId').val(data['tbl_persona_CCMS_ID']);
                $('#usuarioCCMS').val(data['tbl_persona_USUARIO_CCMS']);
                $('#fechaIngresoTP').val(data['tbl_persona_FECHA_INGRESO_TP']);
                $('#estadoCivil').val(data['tbl_persona_ESTDO_CIVIL']);
                $('#hijo').val(data['tbl_persona_HIJO']);
                $('#barrio').val(data['tbl_persona_BARRIO']);
                $('#ciudad').val(data['tbl_persona_CIUDAD']);
                $('#nombreInstitucion').val(data['tbl_persona_NOMBRE_INSTITUCION']);
                $('#tipoCarrera').val(data['tbl_persona_CARRERA']);
                $('#correoPersonal').val(data['tbl_persona_CORREO_PERSONAL']);
                $('#plaza').val(data['tbl_persona_PLAZA']);
                $('#grupoSanguinio').val(data['tbl_persona_GRUPO_SANGUINIO']);
                $('#afp').val(data['tbl_persona_AFP']);
                $('#equipoCompuesto').val(data['tbl_persona_EQUIPO_COMPUESTO']);
                $('#observaciones').val(data['tbl_persona_OBSERVACIONES']);
            }).fail((xhr, textStatus, errorThrown) => {
                console.log('Error en la solicitud AJAX:', errorThrown);
            });
        }
    }

    // Llama a la función para cargar los datos cuando la página se carga completamente
    $(document).ready(function() {
        CargarDatos();
    });


    function Crear() {
        // Obtener los valores de los campos
        var nombres = $('#nombres').val();
        var apellidos = $('#apellidos').val();
        var usuarioRed = $('#usuarioRed').val();
        var cargoTP = $('#cargoTP').val();
        var correoCorporativo = $('#correoCorporativo').val();
        var centroCosto = $('#centroCosto').val();
        var direccion = $('#direccion').val();
        var fechaNacimiento = $('#fechaNacimiento').val();
        var numeroDocumento = $('#numeroDocumento').val();
        var numeroTelefono = $('#numeroTelefono').val();
        var ccmsId = $('#ccmsId').val();
        var usuarioCCMS = $('#usuarioCCMS').val();
        var fechaIngresoTP = $('#fechaIngresoTP').val();
        var estadoCivil = $('#estadoCivil').val();
        var hijo = $('#hijo').val();
        var barrio = $('#barrio').val();
        var ciudad = $('#ciudad').val();
        var nombreInstitucion = $('#nombreInstitucion').val();
        var tipoCarrera = $('#tipoCarrera').val();
        var correoPersonal = $('#correoPersonal').val();
        var plaza = $('#plaza').val();
        var grupoSanguinio = $('#grupoSanguinio').val();
        var afp = $('#afp').val();
        var equipoCompuesto = $('#equipoCompuesto').val();
        var observaciones = $('#cargoTP').val();
        var cargoTP = $('#observaciones').val();

        // Realiza la solicitud Ajax al controlador en el servidor
        $.ajax({
            url: '<?php echo URL_SEE ?>perfil/EditarDatosPersona', // Reemplaza con la URL de tu controlador
            type: 'POST', // Cambia a POST si lo necesitas
            data: {
                nombres: nombres,
                apellidos: apellidos,
                usuarioRed: usuarioRed,
                cargoTP: cargoTP,
                correoCorporativo: correoCorporativo,
                centroCosto: centroCosto,
                direccion: direccion,
                fechaNacimiento: fechaNacimiento,
                numeroDocumento: numeroDocumento,
                numeroTelefono: numeroTelefono,
                ccmsId: ccmsId,
                usuarioCCMS: usuarioCCMS,
                fechaIngresoTP: fechaIngresoTP,
                estadoCivil: estadoCivil,
                hijo: hijo,
                barrio: barrio,
                ciudad: ciudad,
                nombreInstitucion: nombreInstitucion,
                tipoCarrera: tipoCarrera,
                correoPersonal: correoPersonal,
                plaza: plaza,
                grupoSanguinio: grupoSanguinio,
                afp: afp,
                equipoCompuesto: equipoCompuesto,
                observaciones: observaciones
            }
        }).done(function() {
            
            SSwal.fire('Any fool can use a computer')
        }).fail(function() {
            alert('error')
        })
    }
});
</script>