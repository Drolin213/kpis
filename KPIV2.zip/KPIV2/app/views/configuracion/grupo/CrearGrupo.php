<?php require_once "../app/views/template.php"; ?>

<div class="main-content">
    <link rel="stylesheet" href="<?php echo URL_SEE?>/css/group-new.css">
    <link rel="stylesheet" href="<?php echo URL_SEE?>/css/group-members.css">
    <link href="<?php echo URL_SEE?>/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet"
        type="text/css">
    <link href="<?php echo URL_SEE?>/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet"
        type="text/css">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4>Crear grupos</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="">Grupos</a></li>
                            <li class="breadcrumb-item active">Nuevo</li>
                        </ol>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-3 col-sm-6">
                    <div class="card mini-stat bg-primary">
                        <div class="card-body mini-stat-img">
                            <div class="mini-stat-icon">
                                <i class="fa-solid fa-people-group float-end"></i>
                            </div>
                            <div class="text-white">
                                <h6 class="text-uppercase mb-3 font-size-16 text-white">Grupos</h6>
                                <h2 class="mb-4 text-white" id="groupNumber"></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl col-sm-6">
                    <div class="card mini-stat bg-primary">
                        <div class="card-body mini-stat-img">
                            <div class="mini-stat-icon">
                                <i class="fa-solid  fa-user float-end"></i>
                            </div>
                            <div class="text-white">
                                <h6 class="text-uppercase mb-3 font-size-16 text-white">Usuarios</h6>
                                <h2 class="mb-4 text-white" id="usersNumber"></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-xl col-lg-6">
                    <div class="card">
                        <div class="card-body">

                            <h4 class="card-title">Agregar nuevo grupo</h4>
                            <div id="alertNewGroup" style="display: none;">
                                <div class="alert alert-success" role="alert">
                                    <strong class="textAlert">
                                        <p id="textAlertNotification">
                                        </p>
                                    </strong>

                                </div>
                            </div>
                            <form id="formNewGroup">

                                <div class="mb-3">
                                    <label class="form-label">Área</label>
                                    <div>
                                        <select class="form-control" id="area">
                                            <option value="">Seleccionar</option>
                                            <option value="Calidad - Elearning">Calidad - Elearning</option>
                                            <option value="Desarrollo">Desarrollo</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"> Nombre</label>
                                    <div>
                                        <input id="nombres" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Mentor</label>
                                    <div>
                                        <input id="manager" class="form-control" type="text">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"> Descripción</label>
                                    <div>
                                        <textarea id="description" class="form-control" rows="5"></textarea>
                                    </div>
                                </div>

                                <div class="mb-0">
                                    <div>
                                        <button class="btn btn-primary" type="button" id="Crear">
                                            Crear
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                <div class="col-xl-3 col-lg-6" id="tableKpis">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-3">Grupos</h4>
                            <?php $contador = 1; foreach ($datos['ListarGrupo'] as $ListarGrupo): ?>
                            <div class="inbox-wid">

                                <a href="#" data-bs-toggle="modal" data-bs-target=".bs-new-member-modal-lg"
                                    class="text-dark">
                                    <div class="inbox-item">
                                        <div class="inbox-item-img float-start me-3">
                                            <img src="<?php echo URL_SEE?>/images/groups/groups 1.png"
                                                class="avatar-sm rounded-circle" alt="" id="groups1">
                                        </div>
                                        <h6 class="inbox-item-author mt-0 mb-1 font-size-16" id="titleGroup">
                                            <?php echo $ListarGrupo->tbl_grupo_NOMBRES?></h6>
                                        <p class="inbox-item-text text-muted mb-0" id="descriptionGroup">
                                            <?php echo $ListarGrupo->tbl_grupo_DESCRICION?></p>
                                        <p class="inbox-item-date text-muted" id="dateCreate">
                                            <?php echo $ListarGrupo->tbl_grupo_CREAR_FECHA?></p>
                                    </div>
                                </a>

                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>


                <section id="opcionGroups" style="display: block;">
                    <div class="col-sm-6 col-md-3 mt-4">

                        <!--  Modal content for the above nuevo participante -->
                        <div class="modal fade bs-new-member-modal-lg" tabindex="-1" role="dialog"
                            aria-labelledby="myLargeModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="font-size-14 mb-4" id="groupModalNewMember">Editar Grupo
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-hidden="true"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-lg-5">
                                            <div class="mt-4">
                                                <div id="alertModalNewMember" style="display: none;">
                                                    <div class="alert alert-success" role="alert">
                                                        <strong class="textAlert">
                                                            <p id="textAlertModalNewMember">
                                                            </p>
                                                        </strong>
                                                    </div>
                                                </div>

                                                <form onsubmit="return false;">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="formrow-email-input">Area</label>
                                                                <input type="text" class="form-control"
                                                                    value="<?php echo $ListarGrupo->tbl_grupo_AREA?>"
                                                                    readonly>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="formrow-password-input">Nombre</label>
                                                                <input type="text" class="form-control"
                                                                    value="<?php echo $ListarGrupo->tbl_grupos_NOMBRES?>"
                                                                    readonly>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="formrow-email-input">Manager
                                                                    Electronico</label>
                                                                <input type="text" class="form-control"
                                                                    value="<?php echo $ListarGrupo->tbl_grupo_MANAGER?>"
                                                                    readonly>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="formrow-password-input">Descripcion</label>
                                                                <input type="text" class="form-control"
                                                                    value="<?php echo $ListarGrupo->tbl_grupo_DESCRICION?>"
                                                                    readonly>
                                                            </div>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label"
                                                                for="formrow-password-input">Fecha</label>
                                                            <input type="text" class="form-control"
                                                                value="<?php echo $ListarGrupo->tbl_grupo_CREATE_FECHA?>"
                                                                readonly>
                                                        </div>
                                                    </div>
                                            </div>
                                            <div class="mt-4">
                                                <button onclick="loadDataFormNewMember();"
                                                    class="btn btn-primary">Agregar</button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>

                    <!-- /.modal -->
            </div>

            </section>
        </div> <!-- container-fluid -->

    </div>
</div>


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script type="text/javascript">
$(document).ready(function() {

    document.getElementById("Crear").addEventListener('click', function() {
        Crear()
    });

    function Crear() {
        var area = $('#area').val()
        var nombres = $('#nombres').val();
        var manager = $('#manager').val();
        var description = $('#description').val();

        if (area == "" || nombres == "" || manager == "" || description == "") {
            alert('El campo esta vacio')
        } else {

            $.ajax({
                url: '<?php echo URL_SEE ?>grupo/InsertarGrupo',
                type: 'POST',
                data: {
                    area: area,
                    nombres: nombres,
                    manager: manager,
                    description: description
                }
            }).done((respuesta) => {
                console.log(respuesta)
                alert('La vaina se guardo')

                setTimeout(function() {
                    window.location.replace('<?php echo URL_SEE?>grupo/CrearGrupo');
                }, 2000);
            }).fail(function() {
                alert('no se guardo la vaina, implementar sweet alert')
            })

        }
    }

    ToltalGrupo();

    function ToltalGrupo() {
        $.ajax({
            url: '<?php echo URL_SEE ?>grupo/ToltalGrupo', // Reemplaza con la ruta correcta a tu controlador PHP
            type: 'POST',
            // Especifica el tipo de datos esperado
        }).done(function(resp) {
            var total = resp;
            // La respuesta contiene los datos en formato JSON
            $("#groupNumber").text(total);
            //console.log("Total de grupos:", resp);
        })

    }

    Toltalusuario();

    function Toltalusuario() {
        $.ajax({
            url: '<?php echo URL_SEE ?>grupo/Toltalusuario', // Reemplaza con la ruta correcta a tu controlador PHP
            type: 'POST',
            // Especifica el tipo de datos esperado
        }).done(function(resp) {
            var total = resp;
            // La respuesta contiene los datos en formato JSON
            $("#usersNumber").text(total);
            //console.log("Total de grupos:", resp);
        })

    }
});
</script>