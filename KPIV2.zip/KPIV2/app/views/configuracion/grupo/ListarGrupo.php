<?php require_once "../app/views/template.php"; ?>
<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">
            <section id="listgroups">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="page-title-box">
                            <h4>Grupos</h4>
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Grupos</a></li>
                            </ol>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <?php $contador = 1; foreach ($datos['ListarGrupo'] as $ListarGrupo): ?>
                    <div class="col-xl-4 col-md-6">
                        <div class="card directory-card">
                            <div class="directory-bg text-center">
                                <div class="directory-overlay">
                                    <img class="rounded-circle avatar-lg img-thumbnail"
                                        src="<?php echo URL_SEE;?>images/groups/groups 1.png"
                                        alt="Generic placeholder image">
                                </div>
                            </div>

                            <div class="directory-content text-center p-4">
                                <p class=" mt-4">Area</p>
                                <h5 class="font-size-16"> <?php echo $ListarGrupo->tbl_grupo_NOMBRES?></h5>
                                <h5 class="font-size-13"><?php echo $ListarGrupo->tbl_grupo_MANAGER?></h5>

                                <p class="text-muted"> <?php echo $ListarGrupo->tbl_grupo_DESCRICION?></p>

                                <ul class="social-links list-inline mb-0 mt-4">

                                    <li class="list-inline-item">
                                        <a href="<?php echo URL_SEE?>grupoObjectivo/ListarObjectivo?id=<?php echo $ListarGrupo->tbl_grupo_ID?>"  style=" margin-left: 10px;"
                                            class="btn btn-primary btn-round"><i
                                                class="fa-solid fa-arrow-right"></i></a>

                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

           
        </div> <!-- container-fluid -->

    </div>

</div> <!-- container-fluid -->

<script>
var timer = setTimeout(function() {
    $("#Message").fadeOut(1500);
}, 2000);
</script>