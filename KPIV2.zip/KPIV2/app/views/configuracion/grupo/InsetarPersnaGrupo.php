<?php require_once "../app/views/template.php"; ?>

<link rel="stylesheet" href="<?php echo URL_SEE?>/css/group-members.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<style>
/* Estilo base para los resultados */
/* Estilo para el contenedor principal */
#searcd {
    display: inline;
    position: relative;
    /* Oculta la barra de desplazamiento vertical */
}

/* Estilo para los resultados */
#resultadosDiv {
    max-height: 200px;
    overflow: auto;
    position: relative;
    font-size: 13px;
    line-height: 38px;
    right: 16px;
    top: 0;
    color: #5b626b;
    padding: 25px;
    margin: 3px;
}

.resultado {
    padding: 1px;
    margin: -7px;
}

.resultado:hover {
    background-color: #a60bb1c2;
    /* Cambia el color al pasar el ratón por encima */
    color: #fff;
}

.no-result {
    color: #e74c3c;
    /* Cambia el color del mensaje de error */
    font-weight: bold;
    margin-top: 10px;
}
</style>

<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">
            <section id="listgroups" style="display: none;">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="page-title-box">
                            <h4>Grupos</h4>
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Grupos</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="row">

                    <div class="col-xl-4 col-md-6">
                        <div class="card directory-card">
                            <div>
                                <div class="directory-bg text-center">
                                    <div class="directory-overlay">
                                        <img class="rounded-circle avatar-lg img-thumbnail"
                                            src="<?php echo URL_SEE?>/images/groups/groups 1.png"
                                            alt="Generic placeholder image">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="opcionGroups" style="display: block;">
                <div class="col-sm-6 col-md-3 mt-4">
                    <!--  Modal content for the above nuevo participante -->
                    <div class="modal fade bs-new-member-modal-lg" tabindex="-1" role="dialog"
                        aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <i class="mdi mdi-arrow-right text-primary me-1"></i>
                                    <h5 class="font-size-14 mb-4" id="groupModalNewMember">Nuevo integrante - Grupo</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-hidden="true"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="col-lg-5">
                                        <div class="mt-4">
                                            <div id="alertModalNewMember" style="display: none;">
                                                <div class="alert alert-success" role="alert">
                                                    <strong class="textAlert">
                                                        <p id="textAlertModalNewMember"></p>
                                                    </strong>
                                                </div>
                                            </div>

                                            <div class="card-body">
                                                <label class="form-label" for="basic-default-fullname">USER RED</label>
                                                <div class="app-search d-none d-lg-block">
                                                    <div class="position-relative">
                                                        <input type="text" class="form-control" placeholder="Search..."
                                                            id="jsUserCcms">
                                                        <span class="fa fa-search" aria-hidden="true"></span>
                                                        <div class="card" id="searcd">
                                                            <div id="resultadosDiv"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div>
                                                    <div class="row">
                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="nombres">Nombres</label>
                                                                <input type="text" id="nombres" class="form-control"
                                                                    placeholder="Company" value="">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="apellidos">Apellidos</label>
                                                                <input type="text" id="apellidos" class="form-control"
                                                                    placeholder="Last Name" value="">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 pL-1">
                                                            <div class="form-group">
                                                                <label for="usuarioRed">Usuario Red</label>
                                                                <input type="text" id="usuarioRed" class="form-control"
                                                                    placeholder="Username" value="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="cargoTP">Cargo TP</label>
                                                                <input type="text" id="cargoTP" class="form-control"
                                                                    placeholder="Cargo TP" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="correoCorporativo">Correo
                                                                    Corporativo</label>
                                                                <input type="email" id="correoCorporativo"
                                                                    class="form-control" placeholder="Email" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="centroCosto">Centro de Costo</label>
                                                                <input type="text" id="centroCosto" class="form-control"
                                                                    placeholder="Email" value="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="direccion">Direccion</label>
                                                                <input type="text" id="direccion" class="form-control"
                                                                    placeholder="Direccion" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="fechaNacimiento">Fecha de Nacimiento</label>
                                                                <input type="date" id="fechaNacimiento"
                                                                    class="form-control"
                                                                    placeholder="Fecha de Nacimiento" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 px-1">
                                                            <div class="form-group">
                                                                <label for="numeroDocumento">Numero Documento</label>
                                                                <input type="number" id="numeroDocumento"
                                                                    class="form-control" placeholder="Numero Documento"
                                                                    value="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="numeroTelefono">Numero Telefono</label>
                                                                <input type="number" id="numeroTelefono"
                                                                    class="form-control" placeholder="Numero Telefono"
                                                                    value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="ccmsId">CCMS_ID</label>
                                                                <input type="text" id="ccmsId" class="form-control"
                                                                    placeholder="CCMS_ID" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 px-1">
                                                            <div class="form-group">
                                                                <label for="usuarioCCMS">Usuario CCMS</label>
                                                                <input type="text" id="usuarioCCMS" class="form-control"
                                                                    placeholder="Usuario CCMS" value="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="fechaIngresoTP">Fecha de Ingreso TP</label>
                                                                <input type="date" id="fechaIngresoTP"
                                                                    class="form-control"
                                                                    placeholder="Fecha de Ingreso TP" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="estadoCivil">Estado Civil</label>
                                                                <input type="text" id="estadoCivil" class="form-control"
                                                                    placeholder="Estado Civil" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 px-1">
                                                            <div class="form-group">
                                                                <label for="hijo">Hijo</label>
                                                                <input type="text" id="hijo" class="form-control"
                                                                    placeholder="Hijo" value="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="barrio">Barrio</label>
                                                                <input type="text" id="barrio" class="form-control"
                                                                    placeholder="Barrio" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="ciudad">Ciudad</label>
                                                                <input type="text" id="ciudad" class="form-control"
                                                                    placeholder="Ciudad" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 px-1">
                                                            <div class="form-group">
                                                                <label for="nombreInstitucion">Nombre de
                                                                    Institución</label>
                                                                <input type="text" id="nombreInstitucion"
                                                                    class="form-control"
                                                                    placeholder="Nombre de Institución" value="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="tipoCarrera">Tipo de Carrera</label>
                                                                <input type="text" id="tipoCarrera" class="form-control"
                                                                    placeholder="Tipo de Carrera" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 px-1">
                                                            <div class="form-group">
                                                                <label for="nivelCarrera">Nivel de Carrera</label>
                                                                <input type="text" id="nivelCarrera"
                                                                    class="form-control" placeholder="Nivel de Carrera"
                                                                    value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="correoPersonal">Correo Personal</label>
                                                                <input type="email" id="correoPersonal"
                                                                    class="form-control" placeholder="Correo Personal"
                                                                    value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="plaza">Plaza</label>
                                                                <input type="text" id="plaza" class="form-control"
                                                                    placeholder="Plaza" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 px-1">
                                                            <div class="form-group">
                                                                <label for="grupoSanguinio">Grupo Sanguíneo</label>
                                                                <input type="text" id="grupoSanguinio"
                                                                    class="form-control" placeholder="Grupo Sanguíneo"
                                                                    value="">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 pl-1">
                                                            <div class="form-group">
                                                                <label for="afp">AFP</label>
                                                                <input type="text" id="afp" class="form-control"
                                                                    placeholder="AFP" value="">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-4 pr-1">
                                                            <div class="form-group">
                                                                <label for="equipoCompuesto">Equipo Compuesto</label>
                                                                <input type="text" id="equipoCompuesto"
                                                                    class="form-control" placeholder="Equipo Compuesto"
                                                                    value="">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label class="form-label"
                                                                for="formrow-email-input">Grupo</label>
                                                            <div class="col-md-10">
                                                                <select class="form-control" id="Grupo">
                                                                    <option>SELECCIONAR...</option>
                                                                    <?php foreach($datos['TipoGrupo'] as $TipoGrupo): ?>
                                                                    <option
                                                                        data-tokens="<?php echo $TipoGrupo->tbl_grupo_NOMBRES?>"
                                                                        value="<?php echo $TipoGrupo->tbl_grupo_ID?>">
                                                                        <?php echo $TipoGrupo->tbl_grupo_NOMBRES?>
                                                                    </option>
                                                                    <?php endforeach; ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <br>
                                                    <div class="row">
                                                        <div class="update ml-auto mr-auto">
                                                            <button type="submit" id="Crear"
                                                                class="btn btn-primary btn-round">Reguitrar
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="page-title-box">
                            <h4>Grupos</h4>
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a class="aClic">Grupos</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Integrantes</a></li>
                                <li class="breadcrumb-item active">KPIS</li>
                            </ol>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="card mini-stat bg-primary">
                        <div class="card-body mini-stat-img">
                            <div class="mini-stat-icon">
                                <i class="fa-solid fa-people-group float-end"></i>
                            </div>
                            <div class="text-white">
                                <h6 class="text-uppercase mb-3 font-size-16 text-white">Integrantes</h6>
                                <h2 class="mb-4 text-white" id="membersNumber">0</h2>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="card">
                        <div id="alertNewGroup" style="display: none;">
                            <div class="alert alert-success" role="alert">
                                <strong class="textAlert">
                                    <p id="textAlertNotification">
                                    </p>
                                </strong>

                            </div>
                        </div>
                        <div class="card-body">
                            <div class="session2row">
                                <h4 class="card-title">Listado de integrantes.</h4>
                                <div class="text-center-a">
                                    <button type="button" class="btn btn-primary waves-effect waves-light"
                                        data-bs-toggle="modal" data-bs-target=".bs-new-member-modal-lg">
                                        <i class="fa-solid fa-plus"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <div id="resultListGroups_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                            <div class="dataTables_length" id="resultListGroups_length"><label>Show
                                                    <select name="resultListGroups_length"
                                                        aria-controls="resultListGroups"
                                                        class="custom-select custom-select-sm form-control form-control-sm">
                                                        <option value="10">10</option>
                                                        <option value="25">25</option>
                                                        <option value="50">50</option>
                                                        <option value="100">100</option>
                                                    </select> entries</label></div>
                                        </div>
                                        <div class="col-sm-12 col-md-6">
                                            <div id="resultListGroups_filter" class="dataTables_filter">
                                                <label>Search:<input type="search" class="form-control form-control-sm"
                                                        placeholder="" aria-controls="resultListGroups"></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="resultListGroups"
                                                class="table table-bordered dt-responsive nowrap dataTable no-footer dtr-inline"
                                                style="border-collapse: collapse; border-spacing: 0px; width: 100%;"
                                                role="grid" aria-describedby="resultListGroups_info">
                                                <thead>
                                                    <tr role="row">
                                                        <th class="sorting_asc" tabindex="0"
                                                            aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                            style="width: 95.4px;"
                                                            aria-label="Usuario: activate to sort column descending"
                                                            aria-sort="ascending">Usuario</th>
                                                        <th class="sorting" tabindex="0"
                                                            aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                            style="width: 109.4px;"
                                                            aria-label="Nombres: activate to sort column ascending">
                                                            Nombres</th>
                                                        <th class="sorting" tabindex="0"
                                                            aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                            style="width: 110.4px;"
                                                            aria-label="Apellidos: activate to sort column ascending">
                                                            Apellidos</th>
                                                        <th class="sorting" tabindex="0"
                                                            aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                            style="width: 87.4px;"
                                                            aria-label="Correo: activate to sort column ascending">
                                                            Grupo</th>
                                                        <th class="sorting" tabindex="0"
                                                            aria-controls="resultListGroups" rowspan="1" colspan="1"
                                                            style="width: 87.4px;"
                                                            aria-label="Correo: activate to sort column ascending">
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody id="viewResultuserDataCreate">
                                                    <?php $contador = 1; foreach ($datos['ListarGrupoPersona'] as $ListarGrupoPersona): ?>
                                                    <tr>
                                                        <td><?php echo $ListarGrupoPersona->tbl_persona_USUARIO_RED?>
                                                        </td>
                                                        <td><?php echo $ListarGrupoPersona->tbl_persona_NOMBRE?></td>
                                                        <td><?php echo $ListarGrupoPersona->tbl_persona_APELLIDO?></td>
                                                        <td><?php echo $ListarGrupoPersona->tbl_grupo_NOMBRES?></td>

                                                        <?php if ($_SESSION['sesion_active']['tipo_usuario'] == 'ADMINISTRADOR') : ?>
                                                        <td>
                                                            <center>
                                                                <cite title="Editar">
                                                                    <a class="btn btn-info btn-icon-split"
                                                                        href="<?php echo URL_SEE;?>Programa/EditarProgramas/<?php echo $ListarGrupoPersona->tbl_persona_USUARIO_RED;?>">
                                                                        <span class="icon text-white-55">
                                                                            <i class="fas fa-edit"></i>
                                                                        </span>
                                                                    </a>
                                                                </cite>
                                                                <cite title="Borrar">
                                                                    <a class="btn btn-danger btn-icon-split"
                                                                        href="<?php echo URL_SEE;?>Programa/EliminarProgramas/<?php echo $ListarGrupoPersona->tbl_persona_USUARIO_RED;?>">
                                                                        <span class="icon text-white-55">
                                                                            <i class="fas fa-trash"></i>
                                                                        </span>
                                                                    </a>
                                                                </cite>
                                                            </center>
                                                        </td>
                                                        <?php  endif; ?>
                                                    </tr>
                                                    <?php endforeach; ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 col-md-5">
                                            <div class="dataTables_info" id="resultListGroups_info" role="status"
                                                aria-live="polite">Showing 1 to 10 of 100 entries</div>
                                        </div>
                                        <div class="col-sm-12 col-md-7">
                                            <div class="dataTables_paginate paging_simple_numbers"
                                                id="resultListGroups_paginate">
                                                <ul class="pagination">
                                                    <li class="paginate_button page-item previous disabled"
                                                        id="resultListGroups_previous"><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="0"
                                                            tabindex="0" class="page-link">Previous</a></li>
                                                    <li class="paginate_button page-item active"><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="1"
                                                            tabindex="0" class="page-link">1</a></li>
                                                    <li class="paginate_button page-item "><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="2"
                                                            tabindex="0" class="page-link">2</a></li>
                                                    <li class="paginate_button page-item "><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="3"
                                                            tabindex="0" class="page-link">3</a></li>
                                                    <li class="paginate_button page-item "><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="4"
                                                            tabindex="0" class="page-link">4</a></li>
                                                    <li class="paginate_button page-item "><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="5"
                                                            tabindex="0" class="page-link">5</a></li>
                                                    <li class="paginate_button page-item disabled"
                                                        id="resultListGroups_ellipsis"><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="6"
                                                            tabindex="0" class="page-link">…</a></li>
                                                    <li class="paginate_button page-item "><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="7"
                                                            tabindex="0" class="page-link">10</a></li>
                                                    <li class="paginate_button page-item next"
                                                        id="resultListGroups_next"><a href="#"
                                                            aria-controls="resultListGroups" data-dt-idx="8"
                                                            tabindex="0" class="page-link">Next</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>



                </div>

            </section>
        </div> <!-- container-fluid -->

    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"
    integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"
    integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous">
</script>

<script src="https://ajax.googleapis.com/ajax/libs/cesiumjs/1.78/Build/Cesium/Cesium.js"></script>
<script type="text/javascript">
// Variable para almacenar el temporizador del debounce
$(document).ready(function() {
    var timeout; // Variable para el temporizador
    var personasData; // Variable para almacenar los datos de las personas

    $("#jsUserCcms").on('input', function() {
        clearTimeout(timeout); // Limpiar el temporizador anterior si existe

        // Obtener el valor del campo de búsqueda
        var query = $(this).val();

        // Iniciar un nuevo temporizador para la búsqueda después de 500 ms (medio segundo)
        timeout = setTimeout(function() {
            if (query.length >= 4) {
                // Construir la URL con el dato que deseas pasar
                var url = '<?php echo URL_SEE ?>personaGrupo/buscar/' + encodeURIComponent(
                    query);

                // Realizar la solicitud AJAX utilizando la URL construida
                $.ajax({
                    url: url,
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        // Limpiar el contenido anterior del div
                        $("#resultadosDiv").empty();

                        // Guardar los datos de las personas en la variable personasData
                        personasData = data;

                        // Mostrar los resultados en el div
                        if (data.length > 0) {
                            $.each(data, function(index, item) {
                                var resultado = '<div class="resultado">';
                                resultado += item.ID + ', ';
                                resultado += item.nombres + ', ';
                                resultado += item.apellidos + ', ';
                                resultado += item.numeroDocumento + ', ';
                                resultado += item.numeroTelefono;
                                resultado += '</div>';
                                $("#resultadosDiv").append(resultado);
                            });
                        } else {
                            $("#resultadosDiv").html(
                                '<div class="no-result">No se encontraron resultados</div>'
                            );
                        }
                    }
                });
            } else {
                // Si la entrada es demasiado corta, limpiar los resultados
                $("#resultadosDiv").empty();
            }
        }, 500); // Esperar 500 ms después de la última entrada
    });


    // Agregar un controlador de clic a los resultados
    $("#resultadosDiv").on('click', '.resultado', function() {
        // Obtener el índice del elemento clicado en la lista de resultados
        var index = $(this).index();
        // Obtener los datos de la persona seleccionada utilizando el índice
        var personaSeleccionada = personasData[index];
        // Llenar los campos de entrada con los datos de la persona seleccionada
        $("#nombres").val(personaSeleccionada.nombres).prop('readonly', true);
        $("#apellidos").val(personaSeleccionada.apellidos).prop('readonly', true);
        $("#usuarioRed").val(personaSeleccionada.usuarioRed).prop('readonly', true);
        $("#cargoTP").val(personaSeleccionada.cargoTP).prop('readonly', true);
        $("#correoCorporativo").val(personaSeleccionada.correoCorporativo).prop('readonly', true);
        $("#centroCosto").val(personaSeleccionada.centroCosto).prop('readonly', true);
        $("#direccion").val(personaSeleccionada.direccion).prop('readonly', true);
        $("#fechaNacimiento").val(personaSeleccionada.fechaNacimiento).prop('readonly', true);
        $("#numeroDocumento").val(personaSeleccionada.numeroDocumento).prop('readonly', true);
        $("#numeroTelefono").val(personaSeleccionada.numeroTelefono).prop('readonly', true);
        $("#ccmsId").val(personaSeleccionada.ccmsId).prop('readonly', true);
        $("#usuarioCCMS").val(personaSeleccionada.usuarioCCMS).prop('readonly', true);
        $("#fechaIngresoTP").val(personaSeleccionada.fechaIngresoTP).prop('readonly', true);
        $("#estadoCivil").val(personaSeleccionada.estadoCivil).prop('readonly', true);
        $("#hijo").val(personaSeleccionada.hijo).prop('readonly', true);
        $("#barrio").val(personaSeleccionada.barrio).prop('readonly', true);
        $("#ciudad").val(personaSeleccionada.ciudad).prop('readonly', true);
        $("#nombreInstitucion").val(personaSeleccionada.nombreInstitucion).prop('readonly', true);
        $("#tipoCarrera").val(personaSeleccionada.tipoCarrera).prop('readonly', true);
        $("#correoPersonal").val(personaSeleccionada.correoPersonal).prop('readonly', true);
        $("#nivelCarrera").val(personaSeleccionada.nivelCarrera).prop('readonly', true);
        $("#plaza").val(personaSeleccionada.plaza).prop('readonly', true);
        $("#grupoSanguinio").val(personaSeleccionada.grupoSanguinio).prop('readonly', true);
        $("#afp").val(personaSeleccionada.afp).prop('readonly', true);
        $("#equipoCompuesto").val(personaSeleccionada.equipoCompuesto).prop('readonly', true);


    });

    // Limpiar los campos de entrada cuando se borra el contenido de búsqueda
    $("#jsUserCcms").on('change', function() {
        var query = $(this).val();
        if (query.length === 0) {
            $("#nombres, #apellidos, #usuarioRed, nivelCarrera #cargoTP, #correoCorporativo, #centroCosto, #direccion, #fechaNacimiento, #numeroDocumento, #numeroTelefono, #ccmsId, #usuarioCCMS, #fechaIngresoTP, #estadoCivil, #hijo, #barrio, #ciudad, #nombreInstitucion, #tipoCarrera, #correoPersonal, #plaza, #grupoSanguinio, #afp, #equipoCompuesto")
                .val('')
                .prop('readonly', false); // Establecer campos de entrada como editables nuevamente
            // Mostrar el #resultadosDiv
            $("#resultadosDiv").show();
        }
    });




    document.getElementById("Crear").addEventListener('click', function() {
        Crear()
    });

    function Crear() {

        var usuarioRed = $('#usuarioRed').val();
        var Grupo = $('#Grupo').val();

        if (usuarioRed == "" || Grupo == "") {
            alert('El campo esta vacio')
        } else {

            $.ajax({
                url: '<?php echo URL_SEE ?>personaGrupo/InsertarPersonaGrupo',
                type: 'POST',
                data: {
                    Grupo: Grupo,
                    nombres: usuarioRed,

                }
            }).done((respuesta) => {
                console.log(respuesta)
                alert('La vaina se guardo')

                setTimeout(function() {
                    window.location.replace(
                        '<?php echo URL_SEE?>personaGrupo/ListarpersonaGrupo');
                }, 1000);
            }).fail(function() {
                alert('no se guardo la vaina, implementar sweet alert')
            })

        }
    }
});
</script>