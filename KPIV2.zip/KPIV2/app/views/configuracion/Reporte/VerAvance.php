<?php require_once "../app/views/template.php"; ?>


<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4>Jquery Knob Chart</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Lexa</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Charts</a></li>
                            <li class="breadcrumb-item active">Jquery Knob Chart</li>
                        </ol>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="state-information d-none d-sm-block">
                        <div class="state-graph">
                            <div id="header-chart-1"><canvas
                                    style="display: inline-block; width: 101px; height: 32px; vertical-align: top;"
                                    width="101" height="32"></canvas></div>
                            <div class="info">Balance $ 2,317</div>
                        </div>
                        <div class="state-graph">
                            <div id="header-chart-2"><canvas
                                    style="display: inline-block; width: 101px; height: 32px; vertical-align: top;"
                                    width="101" height="32"></canvas></div>
                            <div class="info">Item Sold 1230</div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">Angle offset and arc

                            <h4 class="card-title">Examples</h4>
                            <p class="card-title-desc">Nice, downward compatible, touchable, jQuery dial</p>

                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"
                                    aria-valuemin="0" aria-valuemax="100">25%</div>
                            </div>

                            <div  class="col-ms-4">
                                <img src="<?php echo URL_SEE;?>images/premio.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-Knob/1.2.13/jquery.knob.min.js"></script>

<script>
$('#header-chart-1').sparkline([8, 6, 4, 7, 10, 12, 7, 4, 9, 12, 13, 11, 12], {
    type: 'bar',
    height: '32',
    barWidth: '5',
    barSpacing: '3',
    barColor: '#3eb7ba'
});
$('#header-chart-2').sparkline([8, 6, 4, 7, 10, 12, 7, 4, 9, 12, 13, 11, 12], {
    type: 'bar',
    height: '32',
    barWidth: '5',
    barSpacing: '3',
    barColor: '#7a6fbe'
});
</script>

<!-- Incluye jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Incluye el complemento jQuery Knob -->

<script src="<?php echo URL_SEE;?>js/pages/jquery-knob.init.js"></script>

<script>
$(function() {
    // Inicializa los controles con la clase "knob"
    $(".knob").knob();
});
</script>