<?php require_once "../app/views/template.php"; ?>

<link href="<?php echo URL_SEE;?>libs/@fullcalendar/core/main.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo URL_SEE;?>libs/@fullcalendar/daygrid/main.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo URL_SEE;?>libs/@fullcalendar/bootstrap/main.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo URL_SEE;?>libs/@fullcalendar/timegrid/main.min.css" rel="stylesheet" type="text/css" />

<div class="main-content" id="result">
    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4>Calendar</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Lexa</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Calendar</a></li>
                            <li class="breadcrumb-item active">Calendar</li>
                        </ol>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="state-information d-none d-sm-block">
                        <div class="state-graph">
                            <div id="header-chart-1"></div>
                            <div class="info">Balance $ 2,317</div>
                        </div>
                        <div class="state-graph">
                            <div id="header-chart-2"></div>
                            <div class="info">Item Sold 1230</div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row mb-4">
                <div class="col-xl-3">
                    <div class="card">
                        <div class="card-body d-grid">
                            <button class="btn btn-primary btn-block" id="btn-new-event"><i
                                    class="mdi mdi-plus-circle-outline" type="button"></i> Create New Event</button>


                            <div id="external-events">
                                <br>
                                <p class="text-muted">Arrastra y suelta tu evento o haz clic en el calendario</p>
                                <div class="external-event fc-event bg-success" data-class="bg-success">
                                    <i class="mdi mdi-checkbox-blank-circle font-size-11 me-2"></i>New Event Planning
                                </div>
                                <div class="external-event fc-event bg-info" data-class="bg-info">
                                    <i class="mdi mdi-checkbox-blank-circle font-size-11 me-2"></i>Meeting
                                </div>
                                <div class="external-event fc-event bg-warning" data-class="bg-warning">
                                    <i class="mdi mdi-checkbox-blank-circle font-size-11 me-2"></i>Generating Reports
                                </div>
                                <div class="external-event fc-event bg-danger" data-class="bg-danger">
                                    <i class="mdi mdi-checkbox-blank-circle font-size-11 me-2"></i>Create New theme
                                </div>
                            </div>

                            <div class="mt-5">
                                <h5 class="font-size-14 mb-4">Recent activity :</h5>
                                <?php foreach($datos['ListarObjectivoPersona'] as $ListarObjectivoPersona): ?>

                                <ul class="list-unstyled activity-feed ml-1">
                                    <li class="feed-item">
                                        <div class="feed-item-list">

                                            <div>
                                                <div class="date"><?php echo $ListarObjectivoPersona->tbl_dias_FECHA?>
                                                </div>
                                                <p class="activity-text mb-0">
                                                    <?php echo $ListarObjectivoPersona->tbl_dias_OBSERVACIONES?>
                                                </p>
                                            </div>

                                        </div>
                                    </li>

                                </ul>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div> <!-- end col-->

                <div class="col-xl-9">
                    <div class="card mt-4 mt-xl-0 mb-0">
                        <div class="card-body">
                            <div id="calendar"></div>

                        </div>
                    </div>
                </div> <!-- end col -->

            </div>
            <!-- end row -->


            <!-- Add New Event MODAL -->
            <!-- Add New Event MODAL -->
            <div class="modal fade" id="event-modal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header py-3 px-4 border-bottom-0">
                            <h5 class="modal-title" id="modal-title">Event</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                        </div>
                        <div class="modal-body p-4">
                            <form class="needs-validation" name="event-form" id="form-event">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Objectivo</label>
                                            <?php if ($_SESSION['sesion_active']['tipo_usuario'] == 'ADMINISTR ADOR') : ?>
                                            <!-- Agrega este código HTML a tu página -->
                                            <select id="Listapersonas" class="form-control">
                                                <option>SELECCIONAR...</option>
                                                <?php foreach($datos['Listarpersona'] as $Listarpersona): ?>
                                                <option
                                                    data-tokens="<?php echo $Listarpersona->tbl_grupo_objectivos_NOMBRES?>"
                                                    value="<?php echo $Listarpersona->tbl_grupo_objectivo_ID ?>">
                                                    <?php echo $Listarpersona->tbl_persona_USUARIO_RED?>,
                                                    <?php echo $Listarpersona->tbl_grupo_objectivos_NOMBRES?>,
                                                    <?php echo $Listarpersona->tbl_grupo_objectivo_OBJETIVO?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <?php  endif; ?>


                                            <!-- Agrega este código HTML a tu página -->
                                            <select id="personas" class="form-control">
                                                <option>SELECCIONAR...</option>
                                            </select>
                                            <div class="invalid-feedback">Please select a valid event category</div>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Target</label>
                                            <input class="form-control" placeholder="Insert Event Name" type="number"
                                                name="title" id="event-title" required value="" />
                                            <div class="invalid-feedback">Please provide a valid event name</div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Semana</label>
                                            <select class="form-control custom-select" name="semana" id="semana">
                                                <option selected> --Selected-- </option>
                                                <option value="Semana-1">Semana-1</option>
                                                <option value="Semana-2">Semana-2</option>
                                                <option value="Semana-3">Semana-3</option>
                                                <option value="Semana-4">Semana-4</option>

                                            </select>

                                            <div class="invalid-feedback">Please select a valid event category</div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label class="form-label">Observación:</label>
                                            <div>
                                                <textarea id="observacion" required="" class="form-control"
                                                    rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-6">
                                        <button type="button" class="btn btn-danger"
                                            id="btn-delete-event">Delete</button>
                                    </div>
                                    <div class="col-6 text-end">
                                        <button type="button" class="btn btn-light me-1"
                                            data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success" id="btn-save-event">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div> <!-- end modal-content-->
                </div> <!-- end modal dialog-->
            </div>
            <!-- end modal-->

        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
</div>

<!-- plugin js -->
<script src="<?php echo URL_SEE;?>libs/moment/min/moment.min.js"></script>
<script src="<?php echo URL_SEE;?>libs/jquery-ui-dist/jquery-ui.min.js"></script>
<script src="<?php echo URL_SEE;?>libs/@fullcalendar/core/main.min.js"></script>
<script src="<?php echo URL_SEE;?>libs/@fullcalendar/bootstrap/main.min.js"></script>
<script src="<?php echo URL_SEE;?>libs/@fullcalendar/daygrid/main.min.js"></script>
<script src="<?php echo URL_SEE;?>libs/@fullcalendar/timegrid/main.min.js"></script>
<script src="<?php echo URL_SEE;?>libs/@fullcalendar/interaction/main.min.js"></script>
<script src='<?php echo URL_SEE;?>libs/@fullcalendar/core/locales/es.js'></script>

<script type="text/javascript">
$(document).ready(function() {
    (function($) {
        "use strict";

        var CalendarPage = function() {};

        CalendarPage.prototype.init = function() {
            var addEvent = $("#event-modal");
            var modalTitle = $("#modal-title");
            var formEvent = $("#form-event");
            var selectedEvent = null;
            var newEventData = null;
            var forms = document.getElementsByClassName('needs-validation');
            var eventCategory = $('#event-category');
            var eventCategoryValue = eventCategory
                .val(); // Almacenar el valor original de eventCategory

            /* initialize the calendar */
            var date = new Date();
            var d = date.getDate();
            var m = date.getMonth();
            var y = date.getFullYear();
            var Draggable = FullCalendarInteraction.Draggable;
            var externalEventContainerEl = document.getElementById('external-events');

            // init draggable
            new Draggable(externalEventContainerEl, {
                itemSelector: '.external-event',
                eventData: function(eventEl) {
                    return {
                        title: eventEl.innerText,
                        className: $(eventEl).data('class')
                    };
                }
            });

            var defaultEvents = [
                <?php foreach($datos['ListarEvenct'] as $ListarEvenct): ?> {
                    title: '<?php echo $ListarEvenct->tbl_dias_OBSERVACIONES ?>',
                    start: new Date('<?php echo $ListarEvenct->tbl_dias_FECHA ?>'),
                    className: eventCategoryValue // Usar el valor original de eventCategory
                },
                <?php endforeach; ?>
            ];

            var calendarEl = document.getElementById('calendar');

            function addNewEvent(info) {
                addEvent.modal('show');
                formEvent.removeClass("was-validated");
                formEvent[0].reset();

                $("#event-title").val('');
                eventCategory.val(eventCategoryValue); // Restablecer el valor original de eventCategory
                modalTitle.text('Add Event');
                newEventData = info;
            }

            var calendar = new FullCalendar.Calendar(calendarEl, {
                plugins: ['bootstrap', 'interaction', 'dayGrid', 'timeGrid'],
                editable: true,
                droppable: true,
                selectable: true,
                defaultView: 'dayGridMonth',
                themeSystem: 'bootstrap',
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
                },
                views: {
                    dayGridMonth: {
                        displayEventTime: false, // Oculta la hora en la vista de mes
                    }
                },
                locale: 'es',
                eventClick: function(info) {
                    addEvent.modal('show');
                    formEvent[0].reset();
                    selectedEvent = info.event;
                    $("#event-title").val(selectedEvent.title);
                    eventCategory.val(selectedEvent.classNames[
                        0]); // Establecer el valor seleccionado
                    newEventData = null;
                    modalTitle.text('Edit Event');
                    obtenersemana(selectedDate);
                },
                dateClick: function(info) {
                    addNewEvent(info);

                    // Obtener la fecha seleccionada y el día de la semana en español

                    var selectedDate = info.date;
                    var selectedDay = selectedDate.toLocaleDateString('es', {
                        weekday: 'long'
                    });

                    // Actualizar el campo de título del evento con el día de la semana
                    $("#event-title").val('Title Start: ' + selectedDate
                        .toLocaleDateString() + ' (' + selectedDay + ')');
                },
                eventDrop: function(info) {
                    // Aquí puedes obtener información sobre el evento movido
                    var droppedEvent = info.event;
                    var newStartDate = droppedEvent.start;
                    var newEndDate = droppedEvent.end;

                    // Verificar si newEndDate es null y asignar un valor predeterminado
                    if (newEndDate === null) {
                        newEndDate = new Date(newStartDate);
                        newEndDate.setDate(newEndDate.getDate() +
                            1); // Asumimos una duración de un día completo
                    }

                    // Hacer lo que necesites con la nueva información del evento (por ejemplo, guardarla en la base de datos)
                    console.log("Evento movido a nueva fecha de inicio:", newStartDate);
                    console.log("Evento movido a nueva fecha de fin:", newEndDate);

                    // Realizar una solicitud AJAX para actualizar la ubicación del evento en la base de datos
                    var editarEvent = {
                        title: droppedEvent.id,
                        start: newStartDate,
                        Dia: newStartDate.toLocaleDateString('es', {
                            weekday: 'long'
                        })
                    };
                    $.ajax({
                        type: "POST",
                        url: '<?php echo URL_SEE ?>Reporte/EditarReporte', // Reemplaza con la URL correcta para actualizar el evento
                        data: {
                            editarEvent: JSON.stringify(editarEvent)
                        },
                    }).done(function(respuesta) {
                        console.log("Evento actualizado en la base de datos:",
                            respuesta);
                    }).fail(function(error) {
                        console.log(
                            "Error al actualizar el evento en la base de datos:",
                            error);
                    });
                },
                events: defaultEvents
            });
            calendar.render();

            /* Add new event */
            $(formEvent).on('submit', function(ev) {
                ev.preventDefault();
                var inputs = $('#form-event :input');
                var updatedTitle = $("#event-title").val();
                var updatedCategory =
                    eventCategoryValue; // Usar el valor original de eventCategory

                // Validation
                if (forms[0].checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                    forms[0].classList.add('was-validated');
                } else {
                    if (selectedEvent) {
                        selectedEvent.setProp("title", updatedTitle);
                        selectedEvent.setProp("classNames", [updatedCategory]);
                    } else {
                        var observacion = $("#observacion").val();
                        var semana = $("#semana").val();
                        var usuarioRED = "<?php echo $_SESSION['sesion_active']['ID'] ?>";


                        // Hacer una solicitud AJAX para guardar el evento en la base de datos
                        $.ajax({
                            type: "POST",
                            url: '<?php echo URL_SEE ?>Reporte/InsertarReporte',
                            data: {
                                title: updatedTitle,
                                start: newEventData.date,
                                Dia: newEventData.Dai,
                                personas: personas.value,
                                observacion: observacion,
                                semana: semana,
                                usuarioRED: usuarioRED

                            }, // Especifica el tipo de datos que esperas recibir
                            success: function(response) {
                                //console.log("Respuesta del servidor:", response);
                                setTimeout(function() {
                                    window.location.replace(
                                        '<?php echo URL_SEE?>Reporte/CrearReporte'
                                    );
                                }, 2000); 

                            },
                            error: function(error) {
                                console.log("Error al enviar la solicitud:", error);
                            }
                        })
                    }
                    addEvent.modal('hide');
                }
            });

            $("#btn-delete-event").on('click', function(e) {
                if (selectedEvent) {
                    selectedEvent.remove();
                    selectedEvent = null;
                    addEvent.modal('hide');
                }
            });

            $("#btn-new-event").on('click', function(e) {
                var selectedDate = calendar
                    .getDate(); // Obtiene la fecha actualmente visible en el calendario
                var selectedDay = selectedDate.toLocaleDateString('es', {
                    weekday: 'long'
                }); // Obtiene el día de la semana en español
                addNewEvent({
                    date: selectedDate,
                    Dai: selectedDay
                });
            });

        };

        $.CalendarPage = new CalendarPage();
        $.CalendarPage.Constructor = CalendarPage;
    })(window.jQuery);

    $("#btnnewnote").on('click', function(e) {

        // Abre el nuevo modal, reemplaza 'nuevo-modal-id' con el ID del nuevo modal que deseas mostrar
        $('#event-modal1').modal('show');
    });

    $("#btndeleteevent").on('click', function(e) {
        $('#event-modal1').modal('hide');

        // Elimina todos los eventos mostrados en el modal
        $('#event-modal1').find('.fc-event').remove();

        // Limpia el contenido del modal si es necesario
        $('#event-modal1').find('form')[0].reset();
    });
    // Initializing
    (function($) {
        "use strict";
        $.CalendarPage.init();
    })(window.jQuery);



});


$(document).ready(function() {
    // URL de la solicitud AJAX (reemplaza con la URL correcta)
    var url = '<?php echo URL_SEE ?>Reporte/lost';

    // Realiza la solicitud AJAX utilizando jQuery
    $.ajax({
        url: url,
        type: 'GET',
        dataType: 'json',
    }).done(function(respuesta) {
        console.log(respuesta);
        var selectElement = $('#personas');
        selectElement.empty(); // Limpia cualquier opción existente en el select

        // Agrega la opción predeterminada
        selectElement.append('<option>SELECCIONAR...</option>');

        // Verifica si la respuesta contiene datos
        if (respuesta && respuesta.length > 0) {
            $.each(respuesta, function(index, item) {
                selectElement.append($('<option>', {
                    value: item.tbl_grupo_objectivo_ID,
                    text: item.tbl_grupo_objectivos_NOMBRES + ' - ' +
                        item.tbl_grupo_objectivo_OBJETIVO
                }));
            });
        }
    }).fail(function(jqXHR, textStatus, errorThrown) {
        console.error('Error en la solicitud: ' + textStatus, errorThrown);
    });
});
</script>