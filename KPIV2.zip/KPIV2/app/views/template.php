<?php 
	$template = new Template();
	class Template{
	   public function __construct(){       
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo NAME_SEE;?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta name="author" content="Grupo de Desarrollo">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- App favicon -->
    <link rel="icon" href="<?php echo URL_SEE;?>public/images/favicon.ico" type="ico/png" />

    <link href="<?php echo URL_SEE;?>css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo URL_SEE;?>css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css -->
    <link href="<?php echo URL_SEE;?>css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <!-- Custom Css -->
    <link href="<?php echo URL_SEE;?>css/custom.css" rel="stylesheet" type="text/css" />
    <!-- loader Css -->
    <link href="<?php echo URL_SEE;?>css/loader.css" rel="stylesheet" type="text/css" />

</head>

<body data-sidebar="dark">

    <div id="preloader">
        <div id="loader"></div>
    </div>
    <!-- Sidebar -->
    <!--VALIDACION DEL MENU DINAMICO CON PRIVILEGIOS-->
    <?php 
        if ($_SESSION['sesion_active']['tipo_usuario'] == 'ADMINISTRADOR' ):
            require 'menus/Administrador.php';
        elseif($_SESSION['sesion_active']['tipo_usuario'] == 'I'):
            require 'menus/Instructor.php';
        elseif($_SESSION['sesion_active']['tipo_usuario'] == 'T'):
            require 'menus/Aprendiz.php';
        endif;
    ?>
    <!--FIN SIDEBAR DINAMICO-->
    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php if($_SESSION['sesion_active']['tipo_usuario'] == 'ADMINISTRADOR' ):?>
        <div class="">
            <?php elseif($_SESSION['sesion_active']['tipo_usuario'] == 'I'):?>
            <div class="" style="background-color: #1a508a;">
                <?php elseif($_SESSION['sesion_active']['tipo_usuario'] == 'T'):?>
                <div class="" style="background-color: #032a53;">
                    <?php endif; ?>
                    <!--- Sidemenu -->
                    <div id="sidebar-menu" class="mm-active">

                    </div>
                </div>
            </div>
            <!-- Left Menu Start -->



            <header id="page-topbar">
                <div class="navbar-header">
                    <div class="d-flex">
                        <!-- LOGO -->
                        <div class="navbar-brand-box">
                            <a href="index.html" class="logo logo-dark">
                                <span class="logo-sm">
                                    <img src="<?php echo URL_SEE;?>images/logo-sm.png" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <img src="<?php echo URL_SEE;?>images/logo-dark.png" alt="" height="17">
                                </span>
                            </a>

                            <a href="index.html" class="logo logo-light">
                                <span class="logo-sm">
                                    <img src="<?php echo URL_SEE;?>images/logo-sm.png" alt="" height="22">
                                </span>
                                <span class="logo-lg">
                                    <img src="<?php echo URL_SEE;?>images/logo-light.png" alt="" height="18">
                                </span>
                            </a>
                        </div>

                        <button type="button"
                            class="btn btn-sm px-3 font-size-24 header-item waves-effect vertical-menu-btn">
                            <i class="mdi mdi-menu"></i>
                        </button>


                    </div>

                    <div class="d-flex">

                        <!-- App Search-->
                        <form class="app-search d-none d-lg-block">
                            <div class="position-relative">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="fa fa-search" aria-hidden="true"></span>
                            </div>
                        </form>

                        <div class="dropdown d-inline-block d-lg-none ml-2">
                            <button type="button" class="btn header-item noti-icon waves-effect"
                                id="page-header-search-dropdown" data-bs-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                <i class="mdi mdi-magnify"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                                aria-labelledby="page-header-search-dropdown">

                                <form class="p-3">
                                    <div class="form-group m-0">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Search ..."
                                                aria-label="Recipient's username">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="submit"><i
                                                        class="mdi mdi-magnify"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>



                        <div class="dropdown d-none d-md-block ms-2">
                            <button type="button" class="btn header-item waves-effect" data-bs-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <img class="me-2" src="<?php echo URL_SEE;?>/images/flags/us_flag.jpg"
                                    alt="Header Language" height="16">
                                English <span class="mdi mdi-chevron-down"></span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <img src="<?php echo URL_SEE;?>images/flags/germany_flag.jpg" alt="user-image"
                                        class="me-1" height="12"> <span class="align-middle"> German </span>
                                </a>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <img src="<?php echo URL_SEE;?>images/flags/italy_flag.jpg" alt="user-image"
                                        class="me-1" height="12">
                                    <span class="align-middle"> Italian </span>
                                </a>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <img src="<?php echo URL_SEE;?>images/flags/french_flag.jpg" alt="user-image"
                                        class="me-1" height="12"> <span class="align-middle"> French </span>
                                </a>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <img src="<?php echo URL_SEE;?>images/flags/spain_flag.jpg" alt="user-image"
                                        class="me-1" height="12">
                                    <span class="align-middle"> Spanish </span>
                                </a>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <img src="<?php echo URL_SEE;?>images/flags/russia_flag.jpg" alt="user-image"
                                        class="me-1" height="12"> <span class="align-middle"> Russian </span>
                                </a>
                            </div>
                        </div>

                        <div class="dropdown d-none d-lg-inline-block">
                            <button type="button" class="btn header-item noti-icon waves-effect"
                                data-toggle="fullscreen">
                                <i class="mdi mdi-fullscreen font-size-24"></i>
                            </button>
                        </div>

                        <div class="dropdown d-inline-block ms-1">
                            <button type="button" class="btn header-item noti-icon waves-effect"
                                id="page-header-notifications-dropdown" data-bs-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                                <i class="ti-bell"></i>
                                <span class="badge bg-danger rounded-pill">3</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                                aria-labelledby="page-header-notifications-dropdown">
                                <div class="p-3">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h5 class="m-0"> Notifications (258) </h5>
                                        </div>
                                    </div>
                                </div>
                                <div data-simplebar="init" style="max-height: 230px;">
                                    <div class="simplebar-wrapper" style="margin: 0px;">
                                        <div class="simplebar-height-auto-observer-wrapper">
                                            <div class="simplebar-height-auto-observer"></div>
                                        </div>
                                        <div class="simplebar-mask">
                                            <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                                <div class="simplebar-content-wrapper"
                                                    style="height: auto; overflow: hidden;">
                                                    <div class="simplebar-content" style="padding: 0px;">
                                                        <a href="" class="text-reset notification-item">
                                                            <div class="media">
                                                                <div class="avatar-xs me-3">
                                                                    <span
                                                                        class="avatar-title border-success rounded-circle ">
                                                                        <i class="mdi mdi-cart-outline"></i>
                                                                    </span>
                                                                </div>
                                                                <div class="media-body">
                                                                    <h6 class="mt-0 mb-1">Your order is placed</h6>
                                                                    <div class="text-muted">
                                                                        <p class="mb-1">If several languages coalesce
                                                                            the
                                                                            grammar</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>

                                                        <a href="" class="text-reset notification-item">
                                                            <div class="media">
                                                                <div class="avatar-xs me-3">
                                                                    <span
                                                                        class="avatar-title border-warning rounded-circle ">
                                                                        <i class="mdi mdi-message"></i>
                                                                    </span>
                                                                </div>
                                                                <div class="media-body">
                                                                    <h6 class="mt-0 mb-1">New Message received</h6>
                                                                    <div class="text-muted">
                                                                        <p class="mb-1">You have 87 unread messages</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>

                                                        <a href="" class="text-reset notification-item">
                                                            <div class="media">
                                                                <div class="avatar-xs me-3">
                                                                    <span
                                                                        class="avatar-title border-info rounded-circle ">
                                                                        <i class="mdi mdi-glass-cocktail"></i>
                                                                    </span>
                                                                </div>
                                                                <div class="media-body">
                                                                    <h6 class="mt-0 mb-1">Your item is shipped</h6>
                                                                    <div class="text-muted">
                                                                        <p class="mb-1">It is a long established fact
                                                                            that a
                                                                            reader will</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>

                                                        <a href="" class="text-reset notification-item">
                                                            <div class="media">
                                                                <div class="avatar-xs me-3">
                                                                    <span
                                                                        class="avatar-title border-primary rounded-circle ">
                                                                        <i class="mdi mdi-cart-outline"></i>
                                                                    </span>
                                                                </div>
                                                                <div class="media-body">
                                                                    <h6 class="mt-0 mb-1">Your order is placed</h6>
                                                                    <div class="text-muted">
                                                                        <p class="mb-1">Dummy text of the printing and
                                                                            typesetting industry.</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>

                                                        <a href="" class="text-reset notification-item">
                                                            <div class="media">
                                                                <div class="avatar-xs me-3">
                                                                    <span
                                                                        class="avatar-title border-warning rounded-circle ">
                                                                        <i class="mdi mdi-message"></i>
                                                                    </span>
                                                                </div>
                                                                <div class="media-body">
                                                                    <h6 class="mt-0 mb-1">New Message received</h6>
                                                                    <div class="text-muted">
                                                                        <p class="mb-1">You have 87 unread messages</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                                    </div>
                                    <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                        <div class="simplebar-scrollbar"
                                            style="transform: translate3d(0px, 0px, 0px); display: none;"></div>
                                    </div>
                                    <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                        <div class="simplebar-scrollbar"
                                            style="transform: translate3d(0px, 0px, 0px); display: none;"></div>
                                    </div>
                                </div>
                                <div class="p-2 border-top">
                                    <a class="btn btn-sm btn-link font-size-14 w-100 text-center"
                                        href="javascript:void(0)">
                                        View all
                                    </a>
                                </div>
                            </div>
                        </div>


                        <div class="dropdown d-inline-block">
                            <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img class="rounded-circle header-profile-user"
                                    src="<?php echo URL_SEE;?>/images/users/user-4.jpg" alt="Header Avatar">
                            </button>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!-- item-->
                                <a class="dropdown-item text-danger" data-target="#logoutModal" data-toggle="modal"
                                    href=""><i
                                        class="mdi mdi-power font-size-17 text-muted align-middle me-1 text-danger"></i>
                                    Logout</a>

                            </div>
                        </div>

                    </div>
                </div>
            </header>


            <!-- Right bar overlay-->
            <div class="rightbar-overlay"></div>




            <?php 
            }          
            public function __destruct(){
    ?>


        </div>

        <!-- End of Footer -->
        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Estas seguro que quieres cerrar sesión?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">×</span></button>
                    </div>
                    <div class="modal-body">
                        <h6>Seleciona "Cerrar Sesión" si quieres finalizar sesion.</h6>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                        <a class="btn btn-danger" href="<?php echo URL_SEE;?>Login/Logout">Cerrar Sesión</a>
                    </div>
                </div>
            </div>
        </div>


        <br><br>
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        © 2023 E-learning <span class="d-none d-sm-inline-block"> - Desarrollo <i
                                class="mdi mdi-heart text-danger"></i>
                        </span>
                    </div>
                </div>
            </div>
        </footer>
        <!-- End of Main Content -->

    </div>

</body>

</html>


<!-- JAVASCRIPT -->
<script src="<?php echo URL_SEE ?>libs/jquery/jquery.min.js"></script>
<script src="<?php echo URL_SEE ?>libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo URL_SEE ?>libs/metismenu/metisMenu.min.js"></script>
<script src="<?php echo URL_SEE ?>libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo URL_SEE ?>libs/node-waves/waves.min.js"></script>
<script src="<?php echo URL_SEE ?>libs/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="https://maps.google.com/maps/api/js?key=AIzaSyCtSAR45TFgZjOs4nBFFZnII-6mMHLfSYI"></script>

<!-- App js -->
<script src="<?php echo URL_SEE ?>js/app.js"></script>



<!--   Core JS Files   -->
<script src="<?php echo URL_SEE ?>js/core/bootstrap-material-design.min.js"></script>




<script>
function mayus(e) {
    e.value = e.value.toUpperCase();
}
</script>
<?php
    }
  } 
?>