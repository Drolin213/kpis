<head>
    <title><?php echo NAME_SEE;?></title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" id="bootstrap-css"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo URL_SEE;?>css/styles.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css"
        integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    <!-- loader Css -->
    <link href="<?php echo URL_SEE;?>css/loader.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="<?php echo URL_SEE;?>public/images/favicon.ico" type="ico/png" />



</head>

<body>
    <div id="preloader">
        <div id="loader"></div>
    </div>
    <!------ Include the above in your HEAD tag ---------->
    <!-- <header>
    <span>
    
    </span>
 </header> -->

    <nav class="navbar navbar-expand-lg bg-light text-uppercase  shadow-lg p-3" id="mainNav">
        <div class="container">

            <a class="navbar-brand js-scroll-trigger" href="#page-top">KPIs</a>
            <button
                class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded"
                type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive"
                aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <button class="btn btn-danger m-2" data-toggle="modal" data-target="#adminModal"
                        type="button">Administrador</button>
                </ul>
            </div>
        </div>
    </nav>
    <br>
    <!--end navbar-->

    <!--container-->
    <section>
        <div class="container">
            <div class="row g-0">
                <div class="col-md-4 mx-auto login-sec card o-hidden border-0 shadow-lg my-5">
                    <br><br><br><br>
                    <div class="tab-content " id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                            aria-labelledby="pills-home-tab">
                            <div class="text-center">
                                <?php !empty($datos['messageEstudent']) ? print "<div class='alert alert-danger fade show' role='alert'>{$datos['messageEstudent']}</div>" : $datos = ['messageEstudent' => '']; ?>
                            </div>
                            <center>
                                <h2 class="font-re text-center text-primary">INICIAR SESIÓN<br></h2>
                            </center>
                            <form method="POST" action="<?php echo URL_SEE; ?>Login/SigninAprendiz" class="login-form">
                                <div class="form-group">
                                    <label class="text-uppercase" for="exampleInputEmail1">USUARIO</label>
                                    <input class="form-control" name="STUDENT_USER" placeholder="miusuario@email.com"
                                        type="text" required="El campo no puede ir vacío"></input>
                                </div>
                                <div class="form-group">
                                    <label class="text-uppercase" for="exampleInputPassword1">CONTRASEÑA</label>
                                    <input class="form-control" id="PASSWORD" name="STUDENT_PASS" placeholder="******"
                                        type="password" required=""></input>
                                    <span id="imgContrasena" data-activo=false
                                        class="glyphicon glyphicon-eye-open"></span>
                                </div>
                                <button class="btn btn-primary float-right" type="submit">INGRESAR</button>

                                <br>
                                <br>

                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-7  banner-sec card o-hidden border-0 shadow-lg my-5">
                    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0"
                                class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" class="bg-info" data-bs-target="#carouselExampleIndicators"
                                data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" class="bg-info" data-bs-target="#carouselExampleIndicators"
                                data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img style="width:100%;height:500px;" alt="First slide" class="d-block img-fluid"
                                    src="<?php echo URL_SEE ?>images/undraw1.png">
                                <div class="carousel-caption d-none d-md-block">
                                </div>
                                </img>
                            </div>
                            <div class="carousel-item">
                                <img style="width:100%;height:500px;" alt="First slide" class="d-block img-fluid"
                                    src="<?php echo URL_SEE ?>images/undraw2.png">
                                <div class="carousel-caption d-none d-md-block">
                                </div>
                                </img>
                            </div>
                            <div class="carousel-item">
                                <img style="width:100%;height:500px;" alt="First slide" class="d-block img-fluid"
                                    src="<?php echo URL_SEE ?>images/undraw3.png">
                                <div class="carousel-caption d-none d-md-block">
                                </div>
                                </img>
                            </div>

                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon flech" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>

                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- end container -->
    <!-- Copyright Section-->
    <div class="copyright py-4 text-center text-white" style="margin-top: 0.6em;>
        <div class=" container"><small>Copyright © teleperformance 2023 | Equipo de Desarrollo</small></div>
    </div>
    <!-- Admin Modal -->
    <div class="modal fade" id="adminModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">INICIAR COMO ADMINISTRADOR</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                        aria-labelledby="pills-home-tab">
                        <div class="text-center">
                            <?php !empty($datos['messageAdmin']) ? print "<div class='alert alert-danger fade show' role='alert'>{$datos['messageAdmin']}</div>" : $datos = ['messageAdmin' => '']; ?>
                        </div>
                        <h2 class="text-center color-danger">INICIAR SESIÓN</h2>
                        <form method="POST" action="<?php echo URL_SEE; ?>Login/SigninAdministrador" class="login-form">
                            <div class="form-group">
                                <label class="text-uppercase" for="exampleInputEmail1">USUARIO</label>
                                <input class="form-control" name="ADMIN_USER" placeholder="miusuario@email.com"
                                    type="text" required="El campo no puede ir vacío"></input>
                            </div>
                            <div class="form-group">
                                <label class="text-uppercase" for="exampleInputPassword1">CONTRASEÑA</label>
                                <input class="form-control" id="PASSWORD2" name="ADMIN_PASS" placeholder="******"
                                    type="password" required="Por favor ingrese una contraseña"></input>
                            </div>
                            <button class="btn btn-primary float-right" type="submit">INGRESAR</button>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Profesor Modal -->
    <div class="modal fade" id="TeacherModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel2">INICIAR COMO INSTRUCTOR</h5> <br>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="tab-pane fade show active" id="pills" role="tabpanel" aria-labelledby="pills-home">
                        <div class="text-center">
                            <?php !empty($datos['messageTeacher']) ? print "<div class='alert alert-danger fade show' role='alert'>{$datos['messageTeacher']}</div>" : $datos = ['messageTeacher' => '']; ?>
                        </div>
                        <h2 class="text-center color-danger">INICIAR SESIÓN</h2>
                        <form method="POST" action="<?php echo URL_SEE; ?>Login/SigninInstructor" class="user">
                            <div class="form-group">
                                <label class="text-uppercase" for="Email">USUARIO</label>
                                <input class="form-control" name="TEACHER_USER" placeholder="miusuario@email.com"
                                    type="text" required="El campo no puede ir vacío"></input>
                            </div>
                            <div class="form-group">
                                <label class="text-uppercase" for="Password">CONTRASEÑA</label>
                                <input class="form-control" id="PASSWORD" name="TEACHER_PASS" placeholder="******"
                                    type="password" required="Por favor ingrese una contraseña"></input>
                            </div>
                            <button class="btn btn-primary float-right" type="submit">INGRESAR</button>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
</body>
<script type="text/javascript">
$(document).ready(function() {

    $(document).ready(function() { //Hacia arriba
        irArriba();
    });


});
</script>